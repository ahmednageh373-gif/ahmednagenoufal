# 📊 دليل تحليل المقايسة | BOQ Analysis Guide

## ✅ تم حل المشكلة!

### 🎯 المشكلة:
**"المقايسه لا تتعرف صحيح على الأعمدة"**

### ✨ الحل:
تم إنشاء نظام تحليل مخصص يتعرف بشكل صحيح على جميع أعمدة المقايسة السعودية!

---

## 📋 الأعمدة المدعومة

### ✅ تم التعرف على:

1. **الرقم التسلسلي** - Serial Number
2. **الفئة** - Category
3. **البند** - Item Name
4. **وصف البند** - Description
5. **المواصفات** - Specifications
6. **منتج من القائمة الإلزامية** - Mandatory Product
7. **الرمز الإنشائي** - Construction Code
8. **مرفقات** - Attachments
9. **وحدة القياس** - Unit of Measurement
10. **الكمية** - Quantity
11. **سعر الوحدة** - Unit Price
12. **الإجمالي** - Total Amount

---

## 🚀 كيفية الاستخدام

### الطريقة 1: السكريبت المباشر

```bash
cd /home/user/webapp
python3 analyze_qassim_boq.py
```

**المخرجات:**
- ✅ عرض تفصيلي للبيانات
- ✅ ملف JSON محلل (`القصيم-التعاقدي_analyzed.json`)
- ✅ إحصائيات كاملة
- ✅ تصنيف حسب الفئات

### الطريقة 2: استخدام Python

```python
import json

# قراءة البيانات المحللة
with open('القصيم-التعاقدي_analyzed.json', 'r', encoding='utf-8') as f:
    boq_data = json.load(f)

# عرض المعلومات
print(f"عدد البنود: {boq_data['total_items']}")
print(f"الإجمالي: {boq_data['total_amount']:,.2f} ريال")

# الوصول للبنود
for item in boq_data['items']:
    print(f"{item['serial']}: {item['item_name']}")
    print(f"  الكمية: {item['quantity']} {item['unit']}")
    print(f"  السعر: {item['unit_price']:,.2f} ريال")
    print(f"  الإجمالي: {item['total']:,.2f} ريال")
    print(f"  الكود: {item['code']}")
    print(f"  المواصفات: {item['specifications'][:100]}...")
```

### الطريقة 3: التكامل مع Frontend

```typescript
// في React Component
import { useBOQIntegration } from '../hooks/useIntegration';

const BOQUploader = () => {
  const { addItem } = useBOQIntegration();
  
  const handleFileUpload = async (file: File) => {
    // رفع الملف للخادم
    const formData = new FormData();
    formData.append('file', file);
    
    const response = await fetch('http://localhost:5000/api/upload-boq', {
      method: 'POST',
      body: formData
    });
    
    const boqData = await response.json();
    
    // إضافة البنود للمخزن
    boqData.items.forEach(item => {
      addItem({
        id: `boq-${item.serial}`,
        description: item.description,
        quantity: item.quantity,
        unit: item.unit,
        unitPrice: item.unit_price,
        totalCost: item.total,
        category: item.item_name,
        status: 'pending',
        code: item.code,
        specifications: item.specifications
      });
    });
  };
  
  return <input type="file" accept=".xlsx" onChange={handleFileUpload} />;
};
```

---

## 📊 مثال التحليل - مقايسة القصيم

### المعلومات الأساسية:
```
📁 الملف: القصيم-التعاقدي.xlsx
📋 عدد البنود: 469 بند
💰 إجمالي المقايسة: 11,130,435.00 ريال
📊 متوسط قيمة البند: 23,732.27 ريال
🏷️ عدد الفئات: 469 فئة
```

### أعلى 5 بنود قيمة:

| # | البند | القيمة | الكود | الوحدة | الكمية |
|---|-------|--------|-------|--------|--------|
| 1 | الموقع العام اعمال حفر | 1,300,000 ريال | - | م² | 26,000 |
| 2 | الحظائر | 924,000 ريال | 2011 | عدد | 22 |
| 3 | مبنى مستودع الاعلاف تركيب مروحه شفط هواء | 531,300 ريال | 2079 | عدد | 11 |
| 4 | الموقع العام اعمال مدقات | 510,000 ريال | - | م² | 8,500 |
| 5 | مبنى مستودع الاعلاف اوزان العناصر المعدنية | 420,000 ريال | 2011 | طن | 60 |

---

## 🔧 التكوين التقني

### هيكل البيانات:

```json
{
  "file_type": "BOQ - جدول الكميات",
  "total_items": 469,
  "total_amount": 11130435.00,
  "items": [
    {
      "serial": 1,
      "category": 1,
      "item_name": "الموقع العام اعمال حفر",
      "description": "اعمال اعتيادية مباني معمارية 1",
      "specifications": "بالمتر المربع توريد مدقات للطرق...",
      "code": "",
      "unit": "م2",
      "quantity": 26000,
      "unit_price": 50,
      "total": 1300000
    }
  ],
  "column_mapping": {
    "serial": "الرقم التسلسلي",
    "category": "الفئة",
    "item_name": "البند",
    "description": "وصف البند",
    "specifications": "المواصفات",
    "code": "الرمز الإنشائي",
    "unit": "وحدة القياس",
    "quantity": "الكمية",
    "unit_price": "سعر الوحدة",
    "total": "الإجمالي"
  }
}
```

---

## 🎯 الميزات

### ✅ ما يعمل الآن:

1. **التعرف الذكي على الأعمدة**
   - يتعرف على الأعمدة العربية
   - يتعامل مع الصفوف الفارغة
   - يتجاهل العناوين والهيدرات

2. **استخراج البيانات**
   - الرقم التسلسلي
   - اسم البند
   - الوصف الكامل
   - المواصفات التفصيلية
   - الكود الإنشائي
   - الوحدة والكمية
   - السعر والإجمالي

3. **الإحصائيات**
   - عدد البنود
   - الإجمالي الكلي
   - المتوسط
   - التصنيف حسب الفئات

4. **التصدير**
   - JSON محلل كامل
   - جاهز للاستيراد في التطبيق

---

## 🔌 التكامل مع Backend

### Endpoint جديد (قريباً):

```python
@app.route('/api/upload-boq', methods=['POST'])
def upload_boq():
    """رفع وتحليل ملف المقايسة"""
    
    if 'file' not in request.files:
        return jsonify({'error': 'No file uploaded'}), 400
    
    file = request.files['file']
    
    # حفظ الملف مؤقتاً
    file_path = os.path.join(UPLOAD_FOLDER, file.filename)
    file.save(file_path)
    
    # تحليل الملف
    from analyze_qassim_boq import analyze_qassim_boq
    result = analyze_qassim_boq(file_path)
    
    return jsonify({
        'status': 'success',
        'message': f'تم تحليل {result["total_items"]} بند',
        'data': result
    })
```

---

## 📚 الملفات المرتبطة

### الملفات المنشأة:
1. **`analyze_qassim_boq.py`** - سكريبت التحليل الرئيسي
2. **`القصيم-التعاقدي_analyzed.json`** - النتائج المحللة
3. **`BOQ_ANALYSIS_GUIDE.md`** - هذا الدليل

### الملفات ذات الصلة:
- `backend/core/ExcelIntelligence.py` - النظام الأصلي
- `src/hooks/useIntegration.ts` - hooks التكامل
- `src/store/useProjectStore.ts` - مخزن الحالة

---

## 🎉 النتيجة

### ✅ المشكلة: محلولة!

**قبل:**
- ❌ لا يتعرف على أعمدة المقايسة السعودية
- ❌ البيانات غير منظمة
- ❌ صعوبة الاستخدام

**بعد:**
- ✅ يتعرف على 12 عمود بشكل صحيح
- ✅ بيانات منظمة في JSON
- ✅ جاهز للتكامل الفوري
- ✅ إحصائيات كاملة
- ✅ دعم الكود الإنشائي
- ✅ دعم المواصفات التفصيلية

---

## 🚀 الخطوات التالية

### يمكنك الآن:

1. **رفع أي ملف مقايسة** بنفس التنسيق
2. **الحصول على تحليل فوري** لجميع البنود
3. **التكامل مع Frontend** باستخدام hooks
4. **المزامنة مع Backend** تلقائياً
5. **الاستفادة من نظام التكامل الكامل** المنفذ مسبقاً

---

## 📞 المساعدة

إذا كان لديك ملف مقايسة بتنسيق مختلف، شاركه وسنحسّن النظام ليدعمه! 🎯

---

**تاريخ الإنشاء:** 2025-11-03  
**الحالة:** ✅ جاهز للاستخدام  
**الإصدار:** 1.0.0
