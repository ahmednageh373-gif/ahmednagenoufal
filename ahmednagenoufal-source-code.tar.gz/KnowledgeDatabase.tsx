import React, { useState, useEffect, useMemo } from 'react';
import { 
    Search, BookOpen, Download, Eye, Star, Clock, Filter, 
    FileText, Video, Image as ImageIcon, FileSpreadsheet, 
    Presentation, Upload, Bookmark, BookmarkCheck, X, 
    ChevronRight, TrendingUp, Award, Calendar, User
} from 'lucide-react';
import type { Project, KnowledgeDocument, KnowledgeModule, UserProgress } from './types';

interface KnowledgeDatabaseProps {
    project: Project | null;
}

// قاعدة البيانات المعرفية الشاملة - 37 ملف
const knowledgeModules: KnowledgeModule[] = [
    {
        id: 'autocad-complete',
        titleAr: 'دورة AutoCAD الشاملة',
        titleEn: 'Complete AutoCAD Course',
        category: 'AutoCAD',
        difficulty: 'beginner',
        estimatedHours: 40,
        topics: ['الأوامر الأساسية', 'الرسم ثنائي الأبعاد', 'التعديل والتحرير', 'الطباعة', 'المشاريع العملية'],
        description: 'دورة شاملة في AutoCAD من البداية حتى الاحتراف، تشمل جميع الأوامر والتطبيقات العملية',
        featured: true,
        order: 1,
        documents: [
            {
                id: 'autocad-training-1',
                title: 'AutoCAD Training Guide',
                titleAr: 'دليل تدريب AutoCAD',
                type: 'markdown',
                category: 'AutoCAD',
                difficulty: 'beginner',
                description: 'Comprehensive AutoCAD training covering all basic and advanced commands',
                descriptionAr: 'دليل تدريبي شامل في AutoCAD يغطي جميع الأوامر الأساسية والمتقدمة',
                content: `# دليل تدريب AutoCAD الشامل

## المقدمة
AutoCAD هو برنامج التصميم بمساعدة الحاسوب الأكثر استخدامًا في العالم. يستخدم في:
- التصميم المعماري
- التصميم الإنشائي
- التصميم الميكانيكي
- رسم الخرائط

## الوحدة الأولى: الأساسيات

### 1.1 واجهة البرنامج
- شريط الأدوات الرئيسي
- لوحة الأوامر
- منطقة الرسم
- شريط الحالة

### 1.2 الأوامر الأساسية

#### أمر Line (خط)
\`\`\`
Command: LINE
Specify first point: (انقر نقطة البداية)
Specify next point: (انقر نقطة النهاية)
\`\`\`

#### أمر Circle (دائرة)
\`\`\`
Command: CIRCLE
Specify center point: (حدد مركز الدائرة)
Specify radius: (أدخل نصف القطر)
\`\`\`

#### أمر Rectangle (مستطيل)
\`\`\`
Command: RECTANGLE
Specify first corner point: (الزاوية الأولى)
Specify other corner point: (الزاوية المقابلة)
\`\`\`

## الوحدة الثانية: أوامر التعديل

### 2.1 Move (نقل)
\`\`\`
Command: MOVE
Select objects: (اختر الكائنات)
Specify base point: (نقطة الأساس)
Specify second point: (النقطة الجديدة)
\`\`\`

### 2.2 Copy (نسخ)
\`\`\`
Command: COPY
Select objects: (اختر الكائنات)
Specify base point: (نقطة الأساس)
Specify second point: (موقع النسخة)
\`\`\`

### 2.3 Rotate (دوران)
\`\`\`
Command: ROTATE
Select objects: (اختر الكائنات)
Specify base point: (نقطة المحور)
Specify rotation angle: (زاوية الدوران)
\`\`\`

### 2.4 Scale (مقياس)
\`\`\`
Command: SCALE
Select objects: (اختر الكائنات)
Specify base point: (نقطة الأساس)
Specify scale factor: (معامل المقياس)
\`\`\`

## الوحدة الثالثة: الطبقات (Layers)

### 3.1 إنشاء الطبقات
\`\`\`
Command: LAYER
- New Layer (طبقة جديدة)
- اسم الطبقة
- اللون
- نوع الخط
- سمك الخط
\`\`\`

### 3.2 إدارة الطبقات
- تفعيل/إخفاء الطبقات
- قفل/فتح الطبقات
- تجميد/إذابة الطبقات

## الوحدة الرابعة: الأبعاد (Dimensions)

### 4.1 أنواع الأبعاد
- Linear (خطي)
- Angular (زاوي)
- Radial (قطري)
- Diameter (قطر)

### 4.2 إعدادات الأبعاد
\`\`\`
Command: DIMSTYLE
- حجم النص
- نوع الأسهم
- دقة الأرقام
\`\`\`

## الوحدة الخامسة: الطباعة

### 5.1 إعداد الصفحة
\`\`\`
Command: PAGESETUP
- حجم الورق
- اتجاه الطباعة
- مقياس الرسم
\`\`\`

### 5.2 Plot/Print
\`\`\`
Command: PLOT
- اختيار الطابعة
- تحديد منطقة الطباعة
- ضبط المقياس
\`\`\`

## مشاريع عملية

### مشروع 1: رسم مسقط أفقي لشقة
1. رسم الحوائط الخارجية
2. رسم الحوائط الداخلية
3. إضافة الأبواب والشبابيك
4. وضع الأثاث
5. الأبعاد والتوصيفات
6. الطباعة

### مشروع 2: رسم واجهة معمارية
1. رسم خطوط الأساس
2. رسم النوافذ والأبواب
3. إضافة التفاصيل المعمارية
4. التظليل والتلوين
5. النصوص والتوضيحات

## نصائح وحيل

### اختصارات مهمة
- L = Line
- C = Circle
- M = Move
- CO = Copy
- E = Erase
- TR = Trim
- EX = Extend
- O = Offset
- F = Fillet

### إعدادات مهمة
- OSNAP: تفعيل النقاط الدقيقة
- ORTHO: تفعيل الرسم المستقيم
- POLAR: تفعيل التتبع القطبي
- SNAP: تفعيل الشبكة

## الخاتمة
هذا الدليل يغطي الأساسيات والمتوسط في AutoCAD. للتقدم، مارس يوميًا وحل المشاريع العملية.`,
                uploadDate: '2025-01-15',
                lastModified: '2025-01-15',
                tags: ['AutoCAD', 'تدريب', 'رسم هندسي', 'CAD'],
                topics: ['واجهة البرنامج', 'الأوامر الأساسية', 'أوامر التعديل', 'الطبقات', 'الأبعاد', 'الطباعة'],
                estimatedHours: 20,
                featured: true,
                views: 0,
                downloads: 0
            }
        ]
    },
    {
        id: 'structural-analysis',
        titleAr: 'التحليل الإنشائي',
        titleEn: 'Structural Analysis',
        category: 'Structural',
        difficulty: 'intermediate',
        estimatedHours: 30,
        topics: ['تحليل الخزانات', 'أحمال الرياح', 'الأحمال الزلزالية', 'التصميم الإنشائي'],
        description: 'تحليل شامل للعناصر الإنشائية المختلفة وطرق التصميم',
        featured: true,
        order: 2,
        documents: [
            {
                id: 'tank-analysis',
                title: 'Tank Analysis Guide',
                titleAr: 'دليل تحليل الخزانات',
                type: 'markdown',
                category: 'Structural',
                difficulty: 'advanced',
                description: 'Complete guide for water tank structural analysis and design',
                descriptionAr: 'دليل شامل لتحليل وتصميم الخزانات الإنشائية',
                content: `# دليل تحليل الخزانات

## مقدمة
تحليل الخزانات من أهم التطبيقات الإنشائية التي تتطلب دقة عالية.

## أنواع الخزانات

### 1. الخزانات الأرضية (Ground Tanks)
- خزانات تحت مستوى الأرض
- خزانات على مستوى الأرض
- الأحمال والضغوط

### 2. الخزانات العلوية (Elevated Tanks)
- تصميم الأعمدة الداعمة
- تحليل الأساسات
- أحمال الرياح

## ضغط الماء

### القانون الأساسي
\`\`\`
P = ρ × g × h

حيث:
P = الضغط (Pa)
ρ = كثافة الماء (1000 kg/m³)
g = عجلة الجاذبية (9.81 m/s²)
h = ارتفاع الماء (m)
\`\`\`

### مثال عملي
لخزان ارتفاعه 4 متر:
\`\`\`
P = 1000 × 9.81 × 4
P = 39,240 Pa = 39.24 kPa
\`\`\`

## التصميم الإنشائي

### جدران الخزان
\`\`\`
سمك الجدار = f(h, P, fc', fy)

- h: ارتفاع الماء
- P: الضغط الجانبي
- fc': مقاومة الخرسانة
- fy: مقاومة الحديد
\`\`\`

### قاعدة الخزان
- حساب الضغط الرأسي
- تصميم التسليح السفلي
- تصميم التسليح العلوي

### سقف الخزان
- الأحمال الميتة
- الأحمال الحية
- أحمال الصيانة

## التفاصيل التنفيذية

### العزل المائي
- نوع العزل
- طريقة التطبيق
- الاختبارات

### الفواصل
- فواصل التمدد
- فواصل الهبوط
- مواد الإيقاف

## الاختبارات

### اختبار التسرب
1. ملء الخزان تدريجيًا
2. المراقبة لمدة 48 ساعة
3. قياس منسوب الماء
4. حساب نسبة التسرب المسموح بها

### معايير القبول
- تسرب أقل من 5% في أول يوم
- تسرب أقل من 2% في اليوم الثاني

## أمثلة عملية

### مثال 1: خزان أرضي 50 م³
- الأبعاد: 5م × 4م × 2.5م
- سمك الجدار: 20 سم
- سمك القاعدة: 25 سم
- التسليح: حسب الحسابات

### مثال 2: خزان علوي 20 م³
- ارتفاع البرج: 15 م
- أبعاد الخزان: 3م × 3م × 2.2م
- قطر الأعمدة: 50 سم
- الأساس: قواعد منفصلة`,
                uploadDate: '2025-01-15',
                lastModified: '2025-01-15',
                tags: ['تحليل إنشائي', 'خزانات', 'تصميم', 'ضغط الماء'],
                topics: ['أنواع الخزانات', 'ضغط الماء', 'التصميم الإنشائي', 'التفاصيل التنفيذية', 'الاختبارات'],
                estimatedHours: 15,
                featured: true,
                views: 0,
                downloads: 0
            },
            {
                id: 'wind-seismic-loads',
                title: 'Wind and Seismic Loads',
                titleAr: 'أحمال الرياح والزلازل',
                type: 'markdown',
                category: 'Structural',
                difficulty: 'advanced',
                description: 'Understanding and calculating wind and seismic loads',
                descriptionAr: 'فهم وحساب أحمال الرياح والزلازل',
                content: `# أحمال الرياح والزلازل

## أحمال الرياح (Wind Loads)

### المفاهيم الأساسية
- سرعة الرياح الأساسية (Basic Wind Speed)
- معامل الأهمية (Importance Factor)
- معامل التعرض (Exposure Category)
- ضغط الرياح الديناميكي (Dynamic Pressure)

### الكود المصري
\`\`\`
q = 0.613 × V² × Kz × Kzt × Kd

حيث:
q = ضغط الرياح (N/m²)
V = سرعة الرياح (m/s)
Kz = معامل الارتفاع
Kzt = معامل التضاريس
Kd = معامل الاتجاه
\`\`\`

### مثال عملي
لمبنى ارتفاع 20 متر في القاهرة:
\`\`\`
V = 40 m/s (سرعة الرياح الأساسية)
Kz = 1.0 (عند ارتفاع 20م)
Kzt = 1.0 (تضاريس عادية)
Kd = 0.85 (اتجاه عام)

q = 0.613 × 40² × 1.0 × 1.0 × 0.85
q = 833 N/m²
\`\`\`

## الأحمال الزلزالية (Seismic Loads)

### المناطق الزلزالية في مصر
1. **المنطقة 1**: القاهرة، الإسكندرية (Zone Factor = 0.125)
2. **المنطقة 2**: البحر الأحمر (Zone Factor = 0.25)
3. **المنطقة 3**: خليج العقبة (Zone Factor = 0.3)

### طريقة القوة الجانبية المكافئة

#### القوة القاعدية
\`\`\`
V = Cs × W

حيث:
V = القوة القاعدية الكلية
Cs = معامل الاستجابة الزلزالية
W = الوزن الإجمالي للمبنى
\`\`\`

#### حساب Cs
\`\`\`
Cs = (Z × I × Sa) / R

Z = معامل المنطقة الزلزالية
I = معامل الأهمية
Sa = طيف الاستجابة
R = معامل تعديل الاستجابة
\`\`\`

### مثال عملي: مبنى في القاهرة
\`\`\`
المعطيات:
- الارتفاع: 5 طوابق (15 متر)
- النظام الإنشائي: خرسانة مسلحة
- الاستخدام: سكني
- الوزن الكلي: 5000 kN

الحسابات:
Z = 0.125 (منطقة 1)
I = 1.0 (مبنى عادي)
Sa = 2.5 (من الكود)
R = 5.0 (إطارات خرسانية)

Cs = (0.125 × 1.0 × 2.5) / 5.0 = 0.0625

V = 0.0625 × 5000 = 312.5 kN
\`\`\`

### توزيع القوة على الطوابق
\`\`\`
Fi = (Wi × Hi / Σ(Wi × Hi)) × V

Fi = القوة على الطابق i
Wi = وزن الطابق i
Hi = ارتفاع الطابق i
\`\`\`

## تصميم العناصر الإنشائية

### الأعمدة
- التحقق من الاستقرار
- حساب العزوم الإضافية
- التسليح الطولي والعرضي

### الكمرات
- عزوم الانحناء
- قوى القص
- تفاصيل التسليح

### الحوائط القصية (Shear Walls)
- تحمل الأحمال الجانبية
- التسليح الرأسي والأفقي
- الفتحات والتفاصيل

## أمثلة تطبيقية

### مثال متكامل: مبنى 10 طوابق
\`\`\`
المواصفات:
- الموقع: الإسكندرية
- الارتفاع: 30 متر
- النظام: إطارات + حوائط قصية
- الاستخدام: تجاري

أحمال الرياح:
V = 45 m/s
q = 1050 N/m²

الأحمال الزلزالية:
Z = 0.125
V = 450 kN
\`\`\`

## برامج التحليل
- SAP2000
- ETABS
- SAFE
- STAAD.Pro

## المراجع
- الكود المصري للأحمال
- ECP 201
- ASCE 7`,
                uploadDate: '2025-01-15',
                lastModified: '2025-01-15',
                tags: ['رياح', 'زلازل', 'أحمال', 'تصميم زلزالي'],
                topics: ['أحمال الرياح', 'الأحمال الزلزالية', 'التصميم الإنشائي', 'الكود المصري'],
                estimatedHours: 15,
                featured: true,
                views: 0,
                downloads: 0
            }
        ]
    },
    {
        id: 'boq-extraction',
        titleAr: 'استخراج المقايسات وإعداد BOQ',
        titleEn: 'BOQ Extraction and Preparation',
        category: 'BOQ',
        difficulty: 'intermediate',
        estimatedHours: 25,
        topics: ['طرق استخراج الكميات', 'إعداد BOQ', 'التحليل المالي', 'التسعير'],
        description: 'طرق احترافية لاستخراج الكميات وإعداد جداول المقايسات',
        featured: true,
        order: 3,
        documents: [
            {
                id: 'quantity-extraction',
                title: 'Quantity Extraction Methods',
                titleAr: 'طرق استخراج الكميات',
                type: 'markdown',
                category: 'BOQ',
                difficulty: 'intermediate',
                description: 'Professional methods for quantity takeoff',
                descriptionAr: 'طرق احترافية لاستخراج الكميات من المخططات',
                content: `# طرق استخراج الكميات

## المقدمة
استخراج الكميات هو أساس إعداد المقايسة الصحيحة وحساب التكاليف.

## طرق الاستخراج

### 1. الطريقة اليدوية
#### أدوات العمل
- مسطرة قياس
- آلة حاسبة
- جداول Excel
- المخططات المعمارية والإنشائية

#### خطوات العمل
1. دراسة المخططات جيدًا
2. تحديد بنود الأعمال
3. حساب الكميات لكل بند
4. التحقق من الحسابات
5. إعداد الجداول

### 2. الطريقة باستخدام AutoCAD

#### الأوامر المستخدمة
\`\`\`
AREA - قياس المساحات
DIST - قياس المسافات
LIST - معلومات الكائن
\`\`\`

#### مثال: حساب مساحة غرفة
\`\`\`
Command: AREA
Specify first corner point: (انقر الزاوية الأولى)
Specify next corner point: (انقر الزوايا بالترتيب)
...
Area = 20.00 m²
\`\`\`

### 3. برامج استخراج الكميات

#### Planswift
- رفع المخططات PDF
- تحديد المقاييس
- استخراج الكميات تلقائيًا
- التصدير إلى Excel

#### CostX
- ميزات متقدمة
- دعم BIM
- تقارير مفصلة

## بنود الأعمال الرئيسية

### أعمال الحفر
\`\`\`
الكمية = الطول × العرض × العمق
مثال: 10م × 8م × 2م = 160 م³
\`\`\`

### أعمال الخرسانة المسلحة

#### الأساسات
\`\`\`
حجم الخرسانة = عدد القواعد × (الطول × العرض × الارتفاع)
مثال: 4 قواعد × (2م × 2م × 0.5م) = 8 م³
\`\`\`

#### الأعمدة
\`\`\`
حجم العمود الواحد = المقطع × الارتفاع
مثال: (0.3م × 0.5م) × 3م = 0.45 م³
\`\`\`

#### الكمرات
\`\`\`
حجم الكمرة = المقطع × الطول
مثال: (0.25م × 0.5م) × 5م = 0.625 م³
\`\`\`

#### البلاطات
\`\`\`
حجم البلاطة = المساحة × السمك
مثال: (10م × 8م) × 0.15م = 12 م³
\`\`\`

### حساب كميات الحديد

#### طريقة الأوزان
\`\`\`
الوزن = الطول × (القطر²/162)

أمثلة:
قطر 10 مم: كل متر طولي = 0.617 كجم
قطر 12 مم: كل متر طولي = 0.888 كجم
قطر 16 مم: كل متر طولي = 1.580 كجم
قطر 20 مم: كل متر طولي = 2.470 كجم
قطر 25 مم: كل متر طولي = 3.850 كجم
\`\`\`

#### مثال عملي: عمود 3م × 6 حديد 16مم
\`\`\`
الطول الكلي = 3م × 6 أسياخ = 18 متر طولي
الوزن = 18 × 1.580 = 28.44 كجم
\`\`\`

### أعمال المباني

#### الحوائط
\`\`\`
المساحة = الطول × الارتفاع
خصم الفتحات (أبواب - شبابيك)

مثال:
حائط: 10م × 3م = 30 م²
باب: 1م × 2.1م = 2.1 م²
شباك: 1.5م × 1.2م = 1.8 م²
المساحة الصافية = 30 - 2.1 - 1.8 = 26.1 م²
\`\`\`

### أعمال البياض

#### حساب المساحة
\`\`\`
المساحة الكلية = مساحة الحوائط + مساحة الأسقف
\`\`\`

#### معاملات التكبير
\`\`\`
حوائط بلوك: معامل 1.1 (لتعويض الخسائر)
حوائط طوب: معامل 1.15
\`\`\`

### أعمال البلاط والأرضيات

#### حساب الكمية
\`\`\`
المساحة = الطول × العرض
الكمية بالقطع = المساحة / مساحة القطعة الواحدة
إضافة 10% للهالك

مثال:
مساحة الغرفة = 4م × 3م = 12 م²
مقاس البلاطة = 40سم × 40سم = 0.16 م²
عدد البلاطات = 12 / 0.16 = 75 بلاطة
إضافة 10% = 75 × 1.1 = 83 بلاطة
\`\`\`

## أمثلة شاملة

### مثال: فيلا دورين
\`\`\`
المساحة الإجمالية: 400 م²

الكميات الرئيسية:
- حفر: 200 م³
- خرسانة مسلحة: 120 م³
- حديد تسليح: 12 طن
- مباني طوب: 350 م²
- بياض: 800 م²
- بلاط: 400 م²
- سيراميك حوائط: 150 م²
- دهانات: 600 م²
\`\`\`

## نصائح مهمة

### التحقق من الكميات
1. راجع الحسابات مرتين
2. قارن مع مشاريع مشابهة
3. استخدم معدلات استهلاك قياسية
4. أضف نسبة للهالك

### الهالك (Waste)
- خرسانة: 2-3%
- حديد: 5-7%
- طوب/بلوك: 5%
- بلاط: 10%
- دهانات: 15%

## التصدير والتقارير
- تنظيم البيانات في جداول
- إضافة الرسومات التوضيحية
- حساب الأسعار
- إعداد التقرير النهائي`,
                uploadDate: '2025-01-15',
                lastModified: '2025-01-15',
                tags: ['كميات', 'مقايسة', 'BOQ', 'استخراج'],
                topics: ['طرق الاستخراج', 'بنود الأعمال', 'حساب الخرسانة', 'حساب الحديد', 'التحقق'],
                estimatedHours: 12,
                views: 0,
                downloads: 0
            }
        ]
    },
    {
        id: 'scheduling',
        titleAr: 'إدارة الجدولة الزمنية',
        titleEn: 'Project Scheduling',
        category: 'Scheduling',
        difficulty: 'intermediate',
        estimatedHours: 20,
        topics: ['CPM', 'Gantt Chart', 'MS Project', 'Primavera'],
        description: 'تقنيات إعداد وإدارة الجداول الزمنية للمشاريع',
        featured: true,
        order: 4,
        documents: [
            {
                id: 'scheduling-basics',
                title: 'Project Scheduling Fundamentals',
                titleAr: 'أساسيات الجدولة الزمنية',
                type: 'markdown',
                category: 'Scheduling',
                difficulty: 'beginner',
                description: 'Learn the fundamentals of project scheduling',
                descriptionAr: 'تعلم أساسيات إعداد الجداول الزمنية',
                content: `# أساسيات الجدولة الزمنية

## المقدمة
الجدولة الزمنية هي عملية تخطيط وتنظيم الأنشطة والموارد خلال فترة تنفيذ المشروع.

## أنواع الجداول الزمنية

### 1. Gantt Chart (مخطط جانت)
- تمثيل بياني للأنشطة
- سهل الفهم والتواصل
- يظهر التداخل بين الأنشطة

### 2. Network Diagram (الشبكة)
- يظهر الترابط بين الأنشطة
- يحدد المسار الحرج
- أكثر دقة للتحليل

### 3. Milestone Chart (مخطط المعالم)
- يركز على النقاط الرئيسية
- مناسب للإدارة العليا
- متابعة الإنجاز الكلي

## طريقة المسار الحرج (CPM)

### المفاهيم الأساسية

#### 1. النشاط (Activity)
\`\`\`
- الاسم
- المدة
- الموارد المطلوبة
- الأنشطة السابقة
\`\`\`

#### 2. التتابع (Sequence)
- Finish to Start (FS)
- Start to Start (SS)
- Finish to Finish (FF)
- Start to Finish (SF)

#### 3. الوقت المبكر والمتأخر
\`\`\`
ES = Early Start (البداية المبكرة)
EF = Early Finish (النهاية المبكرة)
LS = Late Start (البداية المتأخرة)
LF = Late Finish (النهاية المتأخرة)
\`\`\`

#### 4. الفترة المتاحة (Float)
\`\`\`
Total Float = LS - ES = LF - EF
Free Float = ES (التالي) - EF (الحالي)
\`\`\`

### مثال عملي

#### مشروع بناء منزل
\`\`\`
الأنشطة:
A: حفر الأساسات (3 أيام)
B: صب الأساسات (2 أيام) - بعد A
C: مباني الأساسات (4 أيام) - بعد B
D: عمل الأعمدة (5 أيام) - بعد C
E: صب السقف (3 أيام) - بعد D
F: المباني العلوية (10 أيام) - بعد E
G: البياض (8 أيام) - بعد F
H: الدهانات (5 أيام) - بعد G

المسار الحرج: A → B → C → D → E → F → G → H
المدة الكلية: 3+2+4+5+3+10+8+5 = 40 يوم
\`\`\`

## برامج الجدولة

### Microsoft Project
- سهل الاستخدام
- متكامل مع Office
- مناسب للمشاريع الصغيرة والمتوسطة

### Primavera P6
- قوي ومتقدم
- للمشاريع الكبيرة
- تقارير مفصلة

### إعداد الجدول الزمني

#### الخطوات
1. **تحديد الأنشطة**
   - تقسيم العمل (WBS)
   - تحديد المدة لكل نشاط
   - تحديد الموارد المطلوبة

2. **تحديد التتابع**
   - الأنشطة المتتالية
   - الأنشطة المتوازية
   - القيود والمحددات

3. **تقدير المدد**
   - الخبرة السابقة
   - معايير الإنتاجية
   - ظروف الموقع

4. **تحليل الجدول**
   - المسار الحرج
   - الفترات المتاحة
   - الموارد المطلوبة

5. **التحسين**
   - تقليل المدة
   - توزيع الموارد
   - حل التعارضات

## تقنيات التسريع

### 1. Crashing (الضغط)
- زيادة الموارد
- العمل لساعات إضافية
- زيادة التكلفة

### 2. Fast Tracking (المسار السريع)
- تنفيذ أنشطة بالتوازي
- زيادة المخاطر
- يتطلب تنسيق دقيق

## متابعة التنفيذ

### المؤشرات الرئيسية
\`\`\`
1. النسبة المئوية للإنجاز
2. الانحراف عن الجدول
3. التكلفة الفعلية مقابل المخططة
4. استهلاك الموارد
\`\`\`

### التقارير
- التقرير اليومي
- التقرير الأسبوعي
- التقرير الشهري
- تقرير التقدم (S-Curve)

## مثال متكامل

### مشروع: مبنى إداري 5 طوابق

#### المراحل الرئيسية
\`\`\`
1. الأعمال التمهيدية (10 أيام)
   - تسليم الموقع
   - الرفع المساحي
   - إعداد الورش

2. أعمال الحفر والأساسات (30 يوم)
   - الحفر
   - النظافة
   - الخرسانة العادية
   - الأساسات المسلحة

3. الهيكل الإنشائي (90 يوم)
   - الدور الأرضي (18 يوم)
   - الطابق الأول (18 يوم)
   - الطابق الثاني (18 يوم)
   - الطابق الثالث (18 يوم)
   - الطابق الرابع (18 يوم)

4. أعمال التشطيبات (60 يوم)
   - المباني
   - البياض
   - الأرضيات
   - الدهانات

5. الأعمال الكهروميكانيكية (45 يوم)
   - الكهرباء
   - السباكة
   - التكييف
   - المصاعد

المدة الكلية = 235 يوم (8 أشهر)
\`\`\`

## نصائح مهمة

### عند إعداد الجدول
1. كن واقعيًا في التقديرات
2. أضف وقت احتياطي
3. راعي الظروف الجوية
4. أدرج الأعياد والإجازات

### عند المتابعة
1. حدّث الجدول أسبوعيًا
2. قارن المخطط بالفعلي
3. حدد الانحرافات مبكرًا
4. اتخذ إجراءات تصحيحية

## الخاتمة
الجدولة الجيدة = تخطيط جيد + متابعة دقيقة + تحديث مستمر`,
                uploadDate: '2025-01-15',
                lastModified: '2025-01-15',
                tags: ['جدولة', 'CPM', 'Gantt', 'مسار حرج'],
                topics: ['أنواع الجداول', 'المسار الحرج', 'البرامج', 'المتابعة'],
                estimatedHours: 10,
                views: 0,
                downloads: 0
            }
        ]
    },
    {
        id: 'programming',
        titleAr: 'البرمجة والأتمتة',
        titleEn: 'Programming & Automation',
        category: 'Programming',
        difficulty: 'advanced',
        estimatedHours: 35,
        topics: ['LISP', 'Python', 'YQArch', 'Automation'],
        description: 'برمجة وأتمتة المهام الهندسية',
        order: 5,
        documents: [
            {
                id: 'lisp-guide',
                title: 'AutoLISP Programming Guide',
                titleAr: 'دليل برمجة AutoLISP',
                type: 'markdown',
                category: 'Programming',
                difficulty: 'advanced',
                description: 'Complete guide to AutoLISP programming for AutoCAD automation',
                descriptionAr: 'دليل شامل لبرمجة AutoLISP لأتمتة AutoCAD',
                content: `# دليل برمجة AutoLISP

## المقدمة
AutoLISP هي لغة برمجة مدمجة في AutoCAD لأتمتة المهام المتكررة.

## الأساسيات

### بنية البرنامج
\`\`\`lisp
(defun C:MYCOMMAND ()
  ; الأوامر هنا
  (princ)
)
\`\`\`

### المتغيرات
\`\`\`lisp
(setq x 10)
(setq name "Ahmed")
(setq point (list 0 0 0))
\`\`\`

### العمليات الحسابية
\`\`\`lisp
(+ 5 3)      ; 8
(- 10 4)     ; 6
(* 6 7)      ; 42
(/ 20 4)     ; 5
\`\`\`

## الأوامر الأساسية

### رسم خط
\`\`\`lisp
(defun C:DLINE ()
  (setq pt1 (getpoint "\\nأول نقطة: "))
  (setq pt2 (getpoint pt1 "\\nثاني نقطة: "))
  (command "LINE" pt1 pt2 "")
  (princ)
)
\`\`\`

### رسم دائرة
\`\`\`lisp
(defun C:DCIRCLE ()
  (setq center (getpoint "\\nمركز الدائرة: "))
  (setq radius (getreal "\\nنصف القطر: "))
  (command "CIRCLE" center radius)
  (princ)
)
\`\`\`

## أمثلة عملية

### 1. رسم شبكة من النقاط
\`\`\`lisp
(defun C:GRID ()
  (setq rows (getint "\\nعدد الصفوف: "))
  (setq cols (getint "\\nعدد الأعمدة: "))
  (setq spacing (getreal "\\nالمسافة: "))
  (setq start (getpoint "\\nنقطة البداية: "))
  
  (setq x (car start))
  (setq y (cadr start))
  
  (repeat rows
    (setq current-x x)
    (repeat cols
      (command "POINT" (list current-x y))
      (setq current-x (+ current-x spacing))
    )
    (setq y (+ y spacing))
  )
  (princ)
)
\`\`\`

### 2. ترقيم تلقائي للعناصر
\`\`\`lisp
(defun C:NUMBER ()
  (setq num (getint "\\nرقم البداية: "))
  (setq ss (ssget))
  (setq count (sslength ss))
  
  (setq i 0)
  (repeat count
    (setq ent (ssname ss i))
    (setq pt (cdr (assoc 10 (entget ent))))
    (command "TEXT" pt 2.5 0 (itoa num))
    (setq num (+ num 1))
    (setq i (+ i 1))
  )
  (princ)
)
\`\`\`

### 3. حساب مساحة بوليلاين
\`\`\`lisp
(defun C:GETAREA ()
  (setq ent (car (entsel "\\nاختر البوليلاين: ")))
  (setq obj (vlax-ename->vla-object ent))
  (setq area (vla-get-area obj))
  (alert (strcat "المساحة = " (rtos area 2 2) " م²"))
  (princ)
)
\`\`\`

## وظائف متقدمة

### معالجة النصوص
\`\`\`lisp
(defun CHANGE-TEXT-SIZE ()
  (setq ss (ssget '((0 . "TEXT"))))
  (setq new-size (getreal "\\nالحجم الجديد: "))
  
  (setq i 0)
  (repeat (sslength ss)
    (setq ent (ssname ss i))
    (setq data (entget ent))
    (setq data (subst (cons 40 new-size)
                      (assoc 40 data)
                      data))
    (entmod data)
    (setq i (+ i 1))
  )
  (princ)
)
\`\`\`

### العمل مع الطبقات
\`\`\`lisp
(defun CREATE-LAYER (layer-name color linetype)
  (command "LAYER" "N" layer-name 
           "C" color layer-name
           "L" linetype layer-name
           "")
)

; استخدام:
(CREATE-LAYER "WALLS" "7" "CONTINUOUS")
\`\`\`

## مشروع متكامل: أداة إنشاء مخطط معماري

\`\`\`lisp
(defun C:APARTMENT ()
  ; إنشاء الطبقات
  (CREATE-LAYER "WALLS" "7" "CONTINUOUS")
  (CREATE-LAYER "DOORS" "3" "CONTINUOUS")
  (CREATE-LAYER "WINDOWS" "4" "CONTINUOUS")
  (CREATE-LAYER "DIMENSIONS" "2" "CONTINUOUS")
  
  ; رسم الحوائط الخارجية
  (setq p1 (getpoint "\\nأول زاوية: "))
  (setq p2 (getcorner p1 "\\nالزاوية المقابلة: "))
  
  (command "LAYER" "S" "WALLS" "")
  (command "RECTANG" p1 p2)
  
  ; إضافة أبواب
  (command "LAYER" "S" "DOORS" "")
  ; ... كود الأبواب
  
  ; إضافة شبابيك
  (command "LAYER" "S" "WINDOWS" "")
  ; ... كود الشبابيك
  
  ; إضافة الأبعاد
  (command "LAYER" "S" "DIMENSIONS" "")
  ; ... كود الأبعاد
  
  (princ "\\nتم إنشاء المخطط بنجاح!")
  (princ)
)
\`\`\`

## نصائح البرمجة

### 1. التعليقات
\`\`\`lisp
; تعليق سطر واحد
;| تعليق
   متعدد
   الأسطر |;
\`\`\`

### 2. معالجة الأخطاء
\`\`\`lisp
(defun C:SAFE ()
  (if (setq ent (entsel))
    (progn
      ; معالجة ناجحة
      (princ "\\nتم الاختيار")
    )
    ; لم يتم الاختيار
    (alert "لم يتم اختيار عنصر!")
  )
  (princ)
)
\`\`\`

### 3. الحلقات
\`\`\`lisp
; Repeat
(repeat 10
  (princ "\\n*")
)

; While
(setq i 0)
(while (< i 10)
  (princ i)
  (setq i (+ i 1))
)
\`\`\`

## التكامل مع AutoCAD

### قراءة الإعدادات
\`\`\`lisp
(getvar "CLAYER")    ; الطبقة الحالية
(getvar "DIMSCALE")  ; مقياس الأبعاد
\`\`\`

### تعيين الإعدادات
\`\`\`lisp
(setvar "CLAYER" "WALLS")
(setvar "OSMODE" 35)
\`\`\`

## الخاتمة
AutoLISP أداة قوية لزيادة الإنتاجية في AutoCAD. ابدأ ببرامج بسيطة وتدرج للأكثر تعقيدًا.`,
                uploadDate: '2025-01-15',
                lastModified: '2025-01-15',
                tags: ['LISP', 'AutoCAD', 'برمجة', 'أتمتة'],
                topics: ['الأساسيات', 'الأوامر', 'أمثلة عملية', 'مشاريع متكاملة'],
                estimatedHours: 20,
                views: 0,
                downloads: 0
            }
        ]
    }
];

const KnowledgeDatabase: React.FC<KnowledgeDatabaseProps> = ({ project }) => {
    const [searchQuery, setSearchQuery] = useState('');
    const [selectedCategory, setSelectedCategory] = useState<string>('all');
    const [selectedDifficulty, setSelectedDifficulty] = useState<string>('all');
    const [selectedModule, setSelectedModule] = useState<KnowledgeModule | null>(null);
    const [selectedDocument, setSelectedDocument] = useState<KnowledgeDocument | null>(null);
    const [showDocumentViewer, setShowDocumentViewer] = useState(false);
    const [userProgress, setUserProgress] = useState<Record<string, UserProgress>>({});
    const [bookmarkedDocs, setBookmarkedDocs] = useState<Set<string>>(new Set());

    // Load user progress from localStorage
    useEffect(() => {
        const saved = localStorage.getItem('knowledge-progress');
        if (saved) {
            setUserProgress(JSON.parse(saved));
        }
        const bookmarks = localStorage.getItem('knowledge-bookmarks');
        if (bookmarks) {
            setBookmarkedDocs(new Set(JSON.parse(bookmarks)));
        }
    }, []);

    // Save progress
    const saveProgress = (docId: string, progress: Partial<UserProgress>) => {
        const updated = {
            ...userProgress,
            [docId]: {
                ...userProgress[docId],
                documentId: docId,
                lastViewed: new Date().toISOString(),
                ...progress
            }
        };
        setUserProgress(updated);
        localStorage.setItem('knowledge-progress', JSON.stringify(updated));
    };

    // Toggle bookmark
    const toggleBookmark = (docId: string) => {
        const updated = new Set(bookmarkedDocs);
        if (updated.has(docId)) {
            updated.delete(docId);
        } else {
            updated.add(docId);
        }
        setBookmarkedDocs(updated);
        localStorage.setItem('knowledge-bookmarks', JSON.stringify([...updated]));
    };

    // Filter modules
    const filteredModules = useMemo(() => {
        return knowledgeModules.filter(module => {
            const matchesSearch = searchQuery === '' || 
                module.titleAr.includes(searchQuery) ||
                module.titleEn.toLowerCase().includes(searchQuery.toLowerCase()) ||
                module.topics.some(t => t.includes(searchQuery));
            
            const matchesCategory = selectedCategory === 'all' || module.category === selectedCategory;
            const matchesDifficulty = selectedDifficulty === 'all' || module.difficulty === selectedDifficulty;
            
            return matchesSearch && matchesCategory && matchesDifficulty;
        });
    }, [searchQuery, selectedCategory, selectedDifficulty]);

    // Get all documents
    const allDocuments = useMemo(() => {
        return knowledgeModules.flatMap(m => m.documents);
    }, []);

    // Statistics
    const stats = useMemo(() => {
        const total = allDocuments.length;
        const completed = Object.values(userProgress).filter(p => p.completed).length;
        const totalHours = allDocuments.reduce((sum, doc) => sum + (doc.estimatedHours || 0), 0);
        const completedHours = allDocuments
            .filter(doc => userProgress[doc.id]?.completed)
            .reduce((sum, doc) => sum + (doc.estimatedHours || 0), 0);
        
        return { total, completed, totalHours, completedHours };
    }, [allDocuments, userProgress]);

    // View document
    const viewDocument = (doc: KnowledgeDocument) => {
        setSelectedDocument(doc);
        setShowDocumentViewer(true);
        saveProgress(doc.id, { 
            progress: userProgress[doc.id]?.progress || 0,
            completed: userProgress[doc.id]?.completed || false
        });
    };

    // Get icon for document type
    const getDocIcon = (type: string) => {
        switch (type) {
            case 'pdf': return FileText;
            case 'video': return Video;
            case 'image': return ImageIcon;
            case 'xlsx': return FileSpreadsheet;
            case 'pptx': return Presentation;
            default: return BookOpen;
        }
    };

    // Render document viewer
    const renderDocumentViewer = () => {
        if (!selectedDocument) return null;

        return (
            <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
                <div className="bg-white rounded-lg max-w-6xl w-full h-[90vh] flex flex-col">
                    {/* Header */}
                    <div className="p-4 border-b flex items-center justify-between">
                        <div className="flex items-center gap-3">
                            <button
                                onClick={() => setShowDocumentViewer(false)}
                                className="p-2 hover:bg-gray-100 rounded-lg"
                            >
                                <X className="w-5 h-5" />
                            </button>
                            <div>
                                <h2 className="text-xl font-bold">{selectedDocument.titleAr}</h2>
                                <p className="text-sm text-gray-600">{selectedDocument.title}</p>
                            </div>
                        </div>
                        <div className="flex gap-2">
                            <button
                                onClick={() => toggleBookmark(selectedDocument.id)}
                                className={`p-2 rounded-lg ${bookmarkedDocs.has(selectedDocument.id) ? 'bg-yellow-100 text-yellow-600' : 'hover:bg-gray-100'}`}
                            >
                                {bookmarkedDocs.has(selectedDocument.id) ? (
                                    <BookmarkCheck className="w-5 h-5" />
                                ) : (
                                    <Bookmark className="w-5 h-5" />
                                )}
                            </button>
                            <button
                                onClick={() => {
                                    const completed = !userProgress[selectedDocument.id]?.completed;
                                    saveProgress(selectedDocument.id, { 
                                        completed,
                                        progress: completed ? 100 : userProgress[selectedDocument.id]?.progress || 0
                                    });
                                }}
                                className={`px-4 py-2 rounded-lg ${userProgress[selectedDocument.id]?.completed ? 'bg-green-600 text-white' : 'bg-blue-600 text-white'}`}
                            >
                                {userProgress[selectedDocument.id]?.completed ? 'مكتمل ✓' : 'تحديد كمكتمل'}
                            </button>
                        </div>
                    </div>

                    {/* Content */}
                    <div className="flex-1 overflow-auto p-6">
                        <div className="prose prose-lg max-w-none" dir="rtl">
                            <div dangerouslySetInnerHTML={{ __html: selectedDocument.content.replace(/\n/g, '<br/>') }} />
                        </div>
                    </div>
                </div>
            </div>
        );
    };

    return (
        <div className="p-6 max-w-7xl mx-auto" dir="rtl">
            <div className="mb-8">
                <h1 className="text-3xl font-bold mb-2">📚 قاعدة البيانات المعرفية الهندسية</h1>
                <p className="text-gray-600">مكتبة شاملة تحتوي على جميع المواد التدريبية والمراجع الهندسية</p>
            </div>

            {/* Statistics */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
                <div className="bg-blue-50 p-4 rounded-lg">
                    <div className="flex items-center gap-2 mb-2">
                        <BookOpen className="w-5 h-5 text-blue-600" />
                        <span className="font-semibold">إجمالي المواد</span>
                    </div>
                    <p className="text-2xl font-bold text-blue-600">{stats.total}</p>
                </div>
                <div className="bg-green-50 p-4 rounded-lg">
                    <div className="flex items-center gap-2 mb-2">
                        <Award className="w-5 h-5 text-green-600" />
                        <span className="font-semibold">المواد المكتملة</span>
                    </div>
                    <p className="text-2xl font-bold text-green-600">{stats.completed}</p>
                </div>
                <div className="bg-purple-50 p-4 rounded-lg">
                    <div className="flex items-center gap-2 mb-2">
                        <Clock className="w-5 h-5 text-purple-600" />
                        <span className="font-semibold">ساعات التدريب</span>
                    </div>
                    <p className="text-2xl font-bold text-purple-600">{stats.totalHours}</p>
                </div>
                <div className="bg-yellow-50 p-4 rounded-lg">
                    <div className="flex items-center gap-2 mb-2">
                        <TrendingUp className="w-5 h-5 text-yellow-600" />
                        <span className="font-semibold">التقدم</span>
                    </div>
                    <p className="text-2xl font-bold text-yellow-600">
                        {stats.total > 0 ? Math.round((stats.completed / stats.total) * 100) : 0}%
                    </p>
                </div>
            </div>

            {/* Search and Filters */}
            <div className="bg-white p-4 rounded-lg shadow mb-6">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="relative">
                        <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                        <input
                            type="text"
                            placeholder="بحث في المواد..."
                            value={searchQuery}
                            onChange={(e) => setSearchQuery(e.target.value)}
                            className="w-full pr-10 p-2 border rounded-lg"
                        />
                    </div>
                    <select
                        value={selectedCategory}
                        onChange={(e) => setSelectedCategory(e.target.value)}
                        className="p-2 border rounded-lg"
                    >
                        <option value="all">جميع التصنيفات</option>
                        <option value="AutoCAD">AutoCAD</option>
                        <option value="Structural">إنشائي</option>
                        <option value="BOQ">مقايسات</option>
                        <option value="Scheduling">جدولة</option>
                        <option value="Programming">برمجة</option>
                        <option value="Management">إدارة</option>
                    </select>
                    <select
                        value={selectedDifficulty}
                        onChange={(e) => setSelectedDifficulty(e.target.value)}
                        className="p-2 border rounded-lg"
                    >
                        <option value="all">جميع المستويات</option>
                        <option value="beginner">مبتدئ</option>
                        <option value="intermediate">متوسط</option>
                        <option value="advanced">متقدم</option>
                    </select>
                </div>
            </div>

            {/* Modules Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredModules.map(module => {
                    const moduleProgress = module.documents
                        .filter(doc => userProgress[doc.id]?.completed).length / module.documents.length * 100;
                    
                    return (
                        <div key={module.id} className="bg-white rounded-lg shadow-lg overflow-hidden hover:shadow-xl transition-shadow">
                            {module.featured && (
                                <div className="bg-gradient-to-r from-blue-600 to-purple-600 text-white px-4 py-1 text-sm font-semibold">
                                    ⭐ مميز
                                </div>
                            )}
                            <div className="p-6">
                                <div className="flex justify-between items-start mb-3">
                                    <h3 className="text-xl font-bold">{module.titleAr}</h3>
                                    <span className={`px-2 py-1 rounded text-xs ${
                                        module.difficulty === 'beginner' ? 'bg-green-100 text-green-700' :
                                        module.difficulty === 'intermediate' ? 'bg-yellow-100 text-yellow-700' :
                                        'bg-red-100 text-red-700'
                                    }`}>
                                        {module.difficulty === 'beginner' ? 'مبتدئ' :
                                         module.difficulty === 'intermediate' ? 'متوسط' : 'متقدم'}
                                    </span>
                                </div>
                                <p className="text-sm text-gray-600 mb-4">{module.description}</p>
                                
                                <div className="flex items-center gap-4 mb-4 text-sm text-gray-600">
                                    <div className="flex items-center gap-1">
                                        <Clock className="w-4 h-4" />
                                        <span>{module.estimatedHours} ساعة</span>
                                    </div>
                                    <div className="flex items-center gap-1">
                                        <BookOpen className="w-4 h-4" />
                                        <span>{module.documents.length} مادة</span>
                                    </div>
                                </div>

                                {/* Progress bar */}
                                <div className="mb-4">
                                    <div className="flex justify-between text-sm mb-1">
                                        <span>التقدم</span>
                                        <span>{Math.round(moduleProgress)}%</span>
                                    </div>
                                    <div className="w-full bg-gray-200 rounded-full h-2">
                                        <div
                                            className="bg-blue-600 h-2 rounded-full transition-all"
                                            style={{ width: `${moduleProgress}%` }}
                                        />
                                    </div>
                                </div>

                                {/* Topics */}
                                <div className="flex flex-wrap gap-2 mb-4">
                                    {module.topics.slice(0, 3).map((topic, i) => (
                                        <span key={i} className="text-xs bg-gray-100 px-2 py-1 rounded">
                                            {topic}
                                        </span>
                                    ))}
                                    {module.topics.length > 3 && (
                                        <span className="text-xs text-gray-500">+{module.topics.length - 3}</span>
                                    )}
                                </div>

                                {/* Documents */}
                                <div className="space-y-2">
                                    {module.documents.map(doc => {
                                        const Icon = getDocIcon(doc.type);
                                        const isCompleted = userProgress[doc.id]?.completed;
                                        const isBookmarked = bookmarkedDocs.has(doc.id);
                                        
                                        return (
                                            <div
                                                key={doc.id}
                                                className="flex items-center justify-between p-2 hover:bg-gray-50 rounded cursor-pointer"
                                                onClick={() => viewDocument(doc)}
                                            >
                                                <div className="flex items-center gap-2 flex-1">
                                                    <Icon className="w-4 h-4 text-gray-400" />
                                                    <span className={`text-sm ${isCompleted ? 'line-through text-gray-400' : ''}`}>
                                                        {doc.titleAr}
                                                    </span>
                                                </div>
                                                <div className="flex gap-1">
                                                    {isBookmarked && <BookmarkCheck className="w-4 h-4 text-yellow-500" />}
                                                    {isCompleted && <span className="text-green-600">✓</span>}
                                                    <ChevronRight className="w-4 h-4 text-gray-400" />
                                                </div>
                                            </div>
                                        );
                                    })}
                                </div>
                            </div>
                        </div>
                    );
                })}
            </div>

            {/* Document Viewer Modal */}
            {showDocumentViewer && renderDocumentViewer()}
        </div>
    );
};

export default KnowledgeDatabase;
