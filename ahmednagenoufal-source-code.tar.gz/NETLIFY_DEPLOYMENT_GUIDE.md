# 🚀 دليل النشر على Netlify - NOUF ERP System

## 📋 طرق النشر المتاحة

---

## ✨ الطريقة 1: النشر التلقائي من GitHub (موصى بها)

### الخطوات:

#### 1️⃣ تسجيل الدخول إلى Netlify
1. اذهب إلى: https://app.netlify.com
2. سجل الدخول بحساب GitHub الخاص بك

#### 2️⃣ إنشاء موقع جديد
1. اضغط على **"Add new site"** → **"Import an existing project"**
2. اختر **"Deploy with GitHub"**
3. ابحث عن المستودع: `ahmednageh373-gif/ahmednagenoufal`
4. اختر المستودع

#### 3️⃣ إعدادات البناء
استخدم هذه الإعدادات:

```
Branch to deploy: main
Base directory: (اتركه فارغاً)
Build command: npm install && npm run build
Publish directory: dist
```

#### 4️⃣ متغيرات البيئة (Environment Variables)
أضف المتغيرات التالية إذا كانت مطلوبة:
```
VITE_APP_NAME=NOUFAL
VITE_BUILD_TIME=production
```

#### 5️⃣ النشر
1. اضغط **"Deploy site"**
2. انتظر حتى يكتمل البناء (2-3 دقائق)
3. سيكون لديك رابط مثل: `https://nouf-erp-xxx.netlify.app`

#### 6️⃣ تخصيص الدومين (اختياري)
- من **"Domain settings"**
- اختر **"Edit site name"**
- غيّر الاسم إلى: `nouf-erp` أو أي اسم تريده

---

## 📦 الطريقة 2: النشر اليدوي بملف ZIP

### الخطوات:

#### 1️⃣ تحضير الملفات
الملف جاهز: `nouf-erp-netlify-deploy.tar.gz` (88 KB)

#### 2️⃣ فك الضغط
```bash
tar -xzf nouf-erp-netlify-deploy.tar.gz
```

#### 3️⃣ النشر على Netlify
1. اذهب إلى: https://app.netlify.com/drop
2. اسحب وأفلت مجلد **`dist`** مباشرة
3. انتظر حتى يكتمل الرفع
4. ستحصل على رابط فوري!

---

## 🔧 الطريقة 3: استخدام Netlify CLI (للمطورين)

### التثبيت:
```bash
npm install -g netlify-cli
```

### تسجيل الدخول:
```bash
netlify login
```

### النشر:
```bash
cd /home/user/webapp
netlify deploy --prod --dir=dist
```

---

## 📊 إعدادات Netlify الموجودة

الملف `netlify.toml` موجود بالفعل مع الإعدادات التالية:

```toml
[build]
  command = "npm install && npm run build"
  publish = "dist"
  
[build.environment]
  NODE_VERSION = "20"
  NPM_VERSION = "10"
  CI = "true"

[[redirects]]
  from = "/*"
  to = "/index.html"
  status = 200
```

---

## ✅ التحقق من النشر

بعد النشر، تحقق من:
- ✅ الصفحة الرئيسية تعمل
- ✅ القائمة الجانبية تعمل
- ✅ التنقل بين الصفحات يعمل
- ✅ لوحة التحكم التنفيذية تعمل
- ✅ نظام إدارة الموارد يعمل
- ✅ نظام التكاليف يعمل
- ✅ الوضع الليلي يعمل

---

## 🔄 التحديثات التلقائية

إذا استخدمت الطريقة 1 (GitHub Integration):
- ✅ كل push إلى branch `main` سينشر تلقائياً
- ✅ يمكنك تفعيل Deploy Previews للـ Pull Requests
- ✅ Rollback متاح لأي نشر سابق

---

## 🌐 أمثلة على الروابط المتوقعة

بعد النشر، ستحصل على روابط مثل:

```
الرابط التلقائي:
https://nouf-erp-abc123.netlify.app

بعد التخصيص:
https://nouf-erp.netlify.app

مع دومين مخصص (اختياري):
https://erp.yourcompany.com
```

---

## 🎯 الرابط الحالي (مؤقت للتطوير)

```
https://3000-iceou6jq7kzmsgq4b495s-3844e1b6.sandbox.novita.ai
```

هذا رابط مؤقت للتطوير فقط. استخدم Netlify للحصول على رابط دائم.

---

## 💡 نصائح مهمة

### للأداء الأفضل:
1. ✅ تأكد من تفعيل **Asset Optimization** في Netlify
2. ✅ فعّل **Form Detection** إذا كان لديك نماذج
3. ✅ استخدم **Split Testing** لاختبار التحديثات

### للأمان:
1. ✅ فعّل HTTPS (مفعّل تلقائياً)
2. ✅ أضف **Content Security Policy** headers
3. ✅ فعّل **Branch Deploy** للاختبار قبل الإنتاج

### للتحليلات:
1. ✅ فعّل **Netlify Analytics** (مدفوع)
2. ✅ أو أضف Google Analytics
3. ✅ راقب **Deploy Logs** للأخطاء

---

## 🆘 حل المشاكل الشائعة

### المشكلة: 404 عند التنقل
**الحل:** تأكد من وجود ملف `_redirects` في مجلد `dist`:
```
/*    /index.html   200
```

### المشكلة: فشل البناء
**الحل:** تحقق من:
- Node.js version (20 أو أحدث)
- npm version (10 أو أحدث)
- جميع dependencies موجودة في `package.json`

### المشكلة: الموقع يعمل محلياً لكن لا يعمل على Netlify
**الحل:**
1. نظف الكاش: `npm clean-install`
2. أعد البناء: `npm run build`
3. اختبر مجلد `dist` محلياً

---

## 📞 الدعم

إذا واجهت أي مشكلة:
- 📖 وثائق Netlify: https://docs.netlify.com
- 💬 مجتمع Netlify: https://answers.netlify.com
- 🐛 GitHub Issues: https://github.com/ahmednageh373-gif/ahmednagenoufal/issues

---

## 🎉 النتيجة المتوقعة

بعد اتباع أي من الطرق أعلاه، سيكون لديك:
- ✅ موقع يعمل 24/7
- ✅ HTTPS مجاناً
- ✅ CDN عالمي سريع
- ✅ Unlimited bandwidth
- ✅ تحديثات تلقائية من GitHub
- ✅ Deploy previews للـ Pull Requests

---

**🚀 جاهز للانطلاق! ابدأ بالطريقة 1 للحصول على أفضل تجربة.**
