# دليل الإعداد - AN.AI Project Manager

## 🔑 إعداد مفاتيح API

### 1. ملفات البيئة

يحتوي المشروع على ملفين للبيئة:

#### `.env`
```env
VITE_API_KEY=AIzaSyAK_UVp3OsRKnakSBiTOSp9mzkPioy7O3A
API_KEY=AIzaSyAK_UVp3OsRKnakSBiTOSp9mzkPioy7O3A
GEMINI_API_KEY=AIzaSyAK_UVp3OsRKnakSBiTOSp9mzkPioy7O3A
VITE_GEMINI_API_KEY=AIzaSyAK_UVp3OsRKnakSBiTOSp9mzkPioy7O3A
```

#### `.env.local`
```env
GEMINI_API_KEY=AIzaSyAK_UVp3OsRKnakSBiTOSp9mzkPioy7O3A
```

### 2. تغيير مفتاح API

لتغيير مفتاح Gemini API الخاص بك:

1. افتح ملف `.env`
2. استبدل القيمة في جميع السطور الأربعة
3. افتح ملف `.env.local`
4. استبدل القيمة أيضاً
5. أعد تشغيل الخادم

```bash
npm run dev
```

## 🚀 تشغيل المشروع

### المتطلبات
- Node.js (الإصدار 18 أو أحدث)
- npm أو yarn

### الخطوات

#### 1. تثبيت الحزم
```bash
npm install
```

#### 2. إعداد مفاتيح API
تأكد من أن ملفات `.env` و `.env.local` تحتوي على مفاتيح API صحيحة.

#### 3. تشغيل خادم التطوير
```bash
npm run dev
```

الخادم سيعمل على: `http://localhost:3000`

#### 4. بناء للإنتاج
```bash
npm run build
```

#### 5. معاينة البناء
```bash
npm run preview
```

## 🔧 إعدادات Vite

### المضيفات المسموح بها
تم إعداد `vite.config.ts` للسماح بالمضيفات التالية:
- `localhost`
- `127.0.0.1`
- `.sandbox.novita.ai` (للبيئات السحابية)

### HMR (Hot Module Replacement)
- البروتوكول: `wss` (WebSocket Secure)
- المنفذ: `443`

## 🌐 الوصول في البيئة السحابية

عند التشغيل في Sandbox:
- الخادم يبحث تلقائياً عن منافذ متاحة (3000, 3001, 3002, ...)
- يمكنك الوصول عبر الرابط السحابي الذي يظهر في الـ Terminal

مثال:
```
https://3002-itzlwp3xwcz18nmpe9ke2-c07dda5e.sandbox.novita.ai
```

## 📦 الحزم الرئيسية

- **React 19.2.0**: مكتبة UI
- **TypeScript 5.8.2**: لغة البرمجة
- **Vite 6.2.0**: أداة البناء
- **@google/genai 1.26.0**: Gemini AI SDK
- **Tailwind CSS**: التنسيقات
- **Lucide React**: الأيقونات
- **XLSX**: معالجة ملفات Excel
- **Recharts**: الرسوم البيانية

## 🐛 حل المشاكل الشائعة

### 1. خطأ "Host not allowed"
✅ **الحل**: تم إصلاحه في `vite.config.ts` بإضافة `.sandbox.novita.ai` إلى `allowedHosts`

### 2. مفتاح API لا يعمل
- تأكد من أن المفتاح صحيح في كلا الملفين `.env` و `.env.local`
- أعد تشغيل الخادم بعد التغيير
- تحقق من أن المفتاح نشط في Google AI Studio

### 3. المنفذ مستخدم بالفعل
- Vite سيبحث تلقائياً عن منفذ متاح
- أو يمكنك إيقاف العملية المستخدمة للمنفذ:
```bash
# Linux/Mac
lsof -ti:3000 | xargs kill -9

# Windows
netstat -ano | findstr :3000
taskkill /PID <PID> /F
```

### 4. أخطاء TypeScript
```bash
# فحص الأخطاء
npx tsc --noEmit

# إصلاح تلقائي لبعض الأخطاء
npm run lint --fix
```

## 📝 ملاحظات مهمة

⚠️ **أمان المفاتيح**:
- لا تشارك ملفات `.env` أو `.env.local` مع أحد
- استخدم `.gitignore` لاستبعادها من Git
- في الإنتاج، استخدم متغيرات البيئة الآمنة

✅ **أفضل الممارسات**:
- احتفظ بنسخة احتياطية من مفاتيح API
- استخدم مفاتيح مختلفة للتطوير والإنتاج
- راقب استخدام API لتجنب تجاوز الحصة

## 🔗 روابط مفيدة

- [Google AI Studio](https://aistudio.google.com/)
- [Vite Documentation](https://vitejs.dev/)
- [React Documentation](https://react.dev/)
- [TypeScript Documentation](https://www.typescriptlang.org/)

---

**آخر تحديث**: 2025-11-01  
**الإصدار**: 1.0.1
