# 🔗 رابط التطبيق الثابت / Stable Application URL

## 📌 الرابط الثابت / Fixed URL:

```
https://3002-ibkd9t405z34j9e71te9h-cbeee0f9.sandbox.novita.ai
```

---

## ✅ ضمان الثبات / Stability Guarantee:

تم تكوين التطبيق للعمل **دائماً** على المنفذ `3002`، مما يضمن ثبات الرابط:

### الإعدادات المطبقة / Applied Configurations:

1. **vite.config.ts:**
   ```typescript
   server: {
     port: 3002,
     strictPort: true  // ← يفرض استخدام 3002 فقط
   }
   ```

2. **.env.local:**
   ```bash
   VITE_PORT=3002
   VITE_APP_URL=https://3002-ibkd9t405z34j9e71te9h-cbeee0f9.sandbox.novita.ai
   ```

3. **package.json:**
   ```json
   "scripts": {
     "dev": "vite"  // ← سيستخدم المنفذ 3002 تلقائياً
   }
   ```

---

## 🚀 تشغيل التطبيق / Starting the App:

### الطريقة العادية / Normal Way:
```bash
cd /home/user/webapp
npm run dev
```

سيبدأ الخادم تلقائياً على المنفذ 3002 ✅

### إذا كان المنفذ مشغولاً / If Port is Busy:
```bash
# إيقاف الخادم الحالي
pkill -f "vite"

# إعادة التشغيل
npm run dev
```

---

## 📍 الوصول لصفحة CAD / Access CAD Page:

### الرابط المباشر / Direct Link:
```
https://3002-ibkd9t405z34j9e71te9h-cbeee0f9.sandbox.novita.ai
```

### المسار في التطبيق / Path in App:
```
القائمة الجانبية → التصميم → 🎨 رسم المخططات (CAD)
Sidebar → Design → 🎨 CAD Drawing
```

---

## 🔧 في حالة تغيير الرابط / If URL Changes:

إذا تغير الرابط لأي سبب، يمكنك الحصول على الرابط الجديد:

### 1. من خلال الكود:
```bash
cd /home/user/webapp
# الرابط الجديد سيظهر في output الخادم
npm run dev
```

### 2. من خلال الأداة:
```bash
# استخدم GetServiceUrl tool للحصول على الرابط
```

---

## 📝 ملاحظات مهمة / Important Notes:

✅ **المنفذ ثابت:** 3002 دائماً (مع `strictPort: true`)
✅ **لا تغيير تلقائي:** حتى لو كان المنفذ مشغولاً، سيفشل التشغيل بدلاً من تغيير المنفذ
✅ **الرابط مستقر:** طالما الخادم يعمل على 3002، الرابط لن يتغير
✅ **HMR يعمل:** التحديثات التلقائية (Hot Module Replacement) تعمل بشكل طبيعي

---

## 🎯 للمطورين / For Developers:

### تغيير المنفذ / Changing Port:

إذا أردت تغيير المنفذ إلى رقم آخر:

1. **عدّل vite.config.ts:**
   ```typescript
   server: {
     port: 3003,  // المنفذ الجديد
     strictPort: true
   }
   ```

2. **عدّل .env.local:**
   ```bash
   VITE_PORT=3003
   VITE_APP_URL=https://3003-...sandbox.novita.ai
   ```

3. **أعد تشغيل الخادم:**
   ```bash
   npm run dev
   ```

---

## 📊 حالة الخادم / Server Status:

**الحالة الحالية / Current Status:** ✅ يعمل على المنفذ 3002

**التحقق من الحالة / Check Status:**
```bash
lsof -ti:3002 && echo "✅ الخادم يعمل" || echo "❌ الخادم متوقف"
```

**إعادة التشغيل / Restart:**
```bash
pkill -f "vite" && npm run dev
```

---

## 🔗 روابط سريعة / Quick Links:

- **التطبيق الرئيسي:** https://3002-ibkd9t405z34j9e71te9h-cbeee0f9.sandbox.novita.ai
- **صفحة CAD:** نفس الرابط ← القائمة → التصميم → 🎨 رسم المخططات
- **Pull Request:** https://github.com/ahmednageh373-gif/ahmednagenoufal/pull/5

---

## ✅ تم التأكيد / Confirmed:

- [x] المنفذ ثابت على 3002
- [x] strictPort مفعّل
- [x] الرابط موثق في .env.local
- [x] الخادم يعمل حالياً
- [x] جميع التعديلات محفوظة في Git
- [x] PR محدث بالرابط الثابت

---

**احفظ هذا الملف للرجوع إليه!** 📌
**Bookmark this file for reference!** 🔖
