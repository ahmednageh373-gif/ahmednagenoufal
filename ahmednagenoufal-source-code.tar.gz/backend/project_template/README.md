# 🏗️ NOUFAL Engineering Project Template
## قالب المشروع الهندسي المتكامل

> **نظام إدارة المشاريع الهندسية**  
> **Integrated Engineering Project Management System**

---

## 📋 نظرة عامة (Overview)

هذا القالب يوفر هيكلاً موحداً ومنظماً لجميع المشاريع الهندسية، مع التركيز على:
- ✅ التكامل بين أدوات التصميم (AutoCAD, Primavera P6)
- ✅ التحليل الآلي للكميات والجداول الزمنية
- ✅ الامتثال لكود البناء السعودي (SBC)
- ✅ التقارير الذكية والمخرجات الاحترافية
- ✅ أفضل ممارسات إدارة المشاريع (PMI/PMP)

---

## 📁 هيكل المشروع (Project Structure)

```
Project_Name/
├── 01_Input_Data/              # البيانات المدخلة
│   ├── 01_CAD/                 # ملفات AutoCAD
│   │   ├── Drawings/           # الرسومات (DWG/DXF)
│   │   └── LISP/               # ملفات LISP المخصصة
│   ├── 02_Schedule/            # الجدول الزمني
│   │   ├── P6_Export/          # تصديرات Primavera P6
│   │   └── MS_Project/         # ملفات MS Project
│   ├── 03_Cost/                # بيانات التكلفة
│   │   └── BOQ_Initial/        # جداول الكميات الأولية
│   └── 04_Site_Data/           # بيانات الموقع
│       └── Daily_Reports/      # التقارير اليومية
│
├── 02_Processing/              # المعالجة والتحليل
│   ├── Scripts/                # وحدات Python البرمجية
│   │   ├── quantity_analysis.py           # تحليل الكميات
│   │   ├── schedule_analysis.py           # تحليل الجدول الزمني
│   │   └── smart_reports_generator.py     # توليد التقارير الذكية
│   └── Temp_Data/              # بيانات مؤقتة
│
└── 03_Output_Data/             # البيانات المخرجة
    ├── 01_Quantities/          # الكميات النهائية
    │   ├── Final_BOQ/          # جداول الكميات النهائية
    │   └── QS_Calculations/    # حسابات الكميات التفصيلية
    ├── 02_Reports/             # التقارير
    │   ├── Weekly_Progress/    # تقارير التقدم الأسبوعية
    │   └── Smart_Reports/      # التقارير الذكية
    ├── 03_Visuals/             # الرسوم البيانية
    │   └── S_Curves/           # منحنيات S-Curve
    └── 04_WBS/                 # هيكل تجزئة العمل
        └── WBS_Structure/      # هيكل WBS المعتمد
```

---

## 🚀 البدء السريع (Quick Start)

### 1. إنشاء مشروع جديد

```bash
# انسخ القالب إلى مجلد مشروعك
cp -r /path/to/project_template /path/to/your/project/Project_Name

cd /path/to/your/project/Project_Name
```

### 2. تثبيت المتطلبات

```bash
pip install -r ../../requirements.txt
```

### 3. وضع الملفات الأولية

1. **ملفات AutoCAD**: ضع ملفات DWG/DXF في `01_Input_Data/01_CAD/Drawings/`
2. **جداول الكميات**: ضع ملف BOQ_Initial.xlsx في `01_Input_Data/03_Cost/BOQ_Initial/`
3. **بيانات الجدول الزمني**: ضع تصديرات P6 في `01_Input_Data/02_Schedule/P6_Export/`
4. **التقارير اليومية**: ضع ملفات CSV في `01_Input_Data/04_Site_Data/Daily_Reports/`

---

## 📊 سير العمل (Workflow)

### الخطوة 1: تحليل الكميات

```python
from Scripts.quantity_analysis import QuantityAnalyzer

# تهيئة المحلل
analyzer = QuantityAnalyzer('/path/to/project')

# تشغيل التحليل الكامل
results = analyzer.run_full_analysis('BOQ_Initial.xlsx')

print(f"تم تحليل {results['total_items']} بند")
print(f"قضايا حرجة: {results['critical_issues']}")
print(f"ملف الإخراج: {results['output_file']}")
```

**المخرجات:**
- ✅ `Final_BOQ.xlsx` - جدول الكميات النهائي مع الحسابات
- ✅ تحقق من الامتثال لكود البناء السعودي (SBC)
- ✅ تنبيهات الجودة والسلامة

---

### الخطوة 2: تحليل الجدول الزمني

```python
from Scripts.schedule_analysis import ScheduleAnalyzer

# تهيئة المحلل
analyzer = ScheduleAnalyzer('/path/to/project')

# تشغيل التحليل الكامل
results = analyzer.run_full_analysis(
    schedule_file='schedule_export.csv',
    progress_file='daily_progress.csv',
    budget=1000000  # الموازنة الإجمالية بالريال
)

print(f"التقدم الفعلي: {results['avg_actual_progress']:.1f}%")
print(f"CPI: {results['evm_metrics']['cost_performance_index']:.2f}")
print(f"SPI: {results['evm_metrics']['schedule_performance_index']:.2f}")
print(f"ملف S-Curve: {results['scurve_file']}")
```

**المخرجات:**
- ✅ منحنى S-Curve (PNG)
- ✅ تحليل المسار الحرج (Critical Path)
- ✅ مؤشرات EVM (CPI, SPI, EAC, etc.)
- ✅ تقارير الانحرافات

---

### الخطوة 3: توليد التقرير الذكي

```python
from Scripts.smart_reports_generator import SmartReportGenerator

# تهيئة المولد
generator = SmartReportGenerator('/path/to/project', 'اسم المشروع')

# تشغيل التوليد الكامل
results = generator.run_full_report_generation(
    quantity_file='Final_BOQ.xlsx',
    schedule_results=schedule_results  # من الخطوة 2
)

print(f"تم إنشاء التقرير: {results['report_file']}")
print(f"قضايا الامتثال: {results['validation_issues']}")
```

**المخرجات:**
- ✅ تقرير Word شامل (DOCX)
- ✅ تحليل ذكي باللغة العربية
- ✅ منحنيات S-Curve مدمجة
- ✅ جداول الامتثال لـ SBC
- ✅ توصيات وملاحظات

---

## 🛠️ المكتبات المستخدمة (Libraries Used)

| المكتبة | الوظيفة | الاستخدام |
|---------|---------|-----------|
| **Pandas** | معالجة البيانات | قراءة وتحليل BOQ والجداول الزمنية |
| **NumPy** | العمليات الرياضية | الحسابات الهندسية |
| **Openpyxl** | ملفات Excel | قراءة وكتابة BOQ |
| **Matplotlib** | الرسوم البيانية | منحنيات S-Curve |
| **python-docx** | ملفات Word | التقارير النهائية |
| **ezdxf** | ملفات DXF | قراءة رسومات AutoCAD |

---

## ⚖️ كود البناء السعودي (Saudi Building Code - SBC)

النظام يتحقق تلقائياً من الامتثال لـ:

### SBC 303: المنشآت الخرسانية
- ✅ قوة الخرسانة الدنيا:
  - أساسات: 25 MPa
  - أعمدة: 30 MPa
  - كمرات: 25 MPa
  - بلاطات: 20 MPa
- ✅ غطاء الخرسانة
- ✅ أقطار الحديد (8-40 mm)
- ✅ المسافات القصوى بين الحديد

### الأبعاد الدنيا
- ✅ سماكة البلاطات: 150 mm
- ✅ عرض الكمرات: 200 mm
- ✅ أبعاد الأعمدة: 250 mm

---

## 📈 مؤشرات EVM (Earned Value Management)

النظام يحسب تلقائياً:

| المؤشر | الرمز | المعنى | الهدف |
|--------|------|--------|-------|
| **Planned Value** | PV | القيمة المخططة | - |
| **Earned Value** | EV | القيمة المكتسبة | - |
| **Actual Cost** | AC | التكلفة الفعلية | - |
| **Cost Variance** | CV | انحراف التكلفة | > 0 |
| **Schedule Variance** | SV | انحراف الجدول | > 0 |
| **Cost Performance Index** | CPI | مؤشر أداء التكلفة | ≥ 1.0 |
| **Schedule Performance Index** | SPI | مؤشر أداء الجدول | ≥ 1.0 |
| **Estimate at Completion** | EAC | التقدير عند الإنجاز | ≤ Budget |
| **Variance at Completion** | VAC | الانحراف عند الإنجاز | ≥ 0 |

---

## 🎯 أفضل الممارسات (Best Practices)

### 1. تنظيم الملفات
- ✅ استخدم أسماء واضحة ومنطقية
- ✅ أرفق تاريخ اليوم في أسماء التقارير (YYYYMMDD)
- ✅ احتفظ بنسخ احتياطية في `Temp_Data`

### 2. الامتثال
- ✅ راجع تنبيهات SBC قبل بدء التنفيذ
- ✅ تأكد من معالجة القضايا الحرجة (Critical)
- ✅ وثّق جميع الاستثناءات

### 3. الجدول الزمني
- ✅ راقب الأنشطة الحرجة يومياً
- ✅ حدّث التقدم الفعلي بشكل دوري
- ✅ تابع مؤشرات CPI/SPI أسبوعياً

### 4. التقارير
- ✅ أنشئ تقارير أسبوعية منتظمة
- ✅ أرفق منحنيات S-Curve المحدثة
- ✅ وثّق التوصيات والقرارات

---

## 🔧 استكشاف الأخطاء (Troubleshooting)

### مشكلة: خطأ في قراءة ملف BOQ

```python
# تأكد من:
# 1. الملف موجود في المسار الصحيح
# 2. اسم الملف صحيح
# 3. صيغة الملف .xlsx

import os
print(os.path.exists('01_Input_Data/03_Cost/BOQ_Initial/BOQ_Initial.xlsx'))
```

### مشكلة: منحنى S-Curve فارغ

```python
# تأكد من:
# 1. وجود بيانات تقدم فعلية
# 2. تطابق activity_id بين الجدول والتقدم
# 3. وجود تواريخ صحيحة

df_schedule['planned_start'] = pd.to_datetime(df_schedule['planned_start'])
```

### مشكلة: تنبيهات SBC كثيرة

```python
# راجع البيانات الأولية:
# 1. تأكد من ذكر قوة الخرسانة في الوصف (25 MPa)
# 2. تأكد من وجود حقل thickness للبلاطات
# 3. راجع أقطار الحديد المستخدمة
```

---

## 📞 الدعم والمساعدة (Support)

### الوثائق الإضافية
- 📄 [دليل المستخدم الكامل](../../docs/guides/user_guide_ar.md)
- 📄 [دليل المطور](../../docs/guides/developer_guide.md)
- 📄 [معايير SBC](../../docs/standards/sbc_standards.md)

### الاتصال
- 📧 Email: support@noufal-engineering.com
- 💬 GitHub Issues: [Create Issue](https://github.com/your-repo/issues)

---

## 📝 ملاحظات إضافية (Additional Notes)

### متطلبات النظام
- Python 3.8 أو أحدث
- 4GB RAM (موصى به: 8GB)
- 2GB مساحة تخزين للمشروع الواحد

### الترخيص
© 2025 NOUFAL Engineering System. All rights reserved.

---

**تم إنشاء هذا القالب بواسطة:**
**NOUFAL Engineering Management System**

*التنظيم • التكامل • الجودة • الابتكار*
