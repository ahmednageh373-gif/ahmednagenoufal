# دليل لوحة التحكم الموحدة
# Unified Dashboard Guide

**التاريخ:** 2025-11-04  
**الإصدار:** 1.0  
**الحالة:** ✅ جاهز للاستخدام

---

## 📋 المحتويات

1. [نظرة عامة](#نظرة-عامة)
2. [المميزات الرئيسية](#المميزات-الرئيسية)
3. [الأدوات المتكاملة](#الأدوات-المتكاملة)
4. [واجهة المستخدم](#واجهة-المستخدم)
5. [API Documentation](#api-documentation)
6. [أمثلة الاستخدام](#أمثلة-الاستخدام)

---

## 🎯 نظرة عامة

**لوحة التحكم الموحدة** هي نقطة الوصول المركزية لجميع أدوات نظام نوفل الهندسي. تدمج أكثر من **30 أداة** في واجهة واحدة سهلة الاستخدام.

### الأهداف الرئيسية

- ✅ **توحيد الوصول** - كل الأدوات في مكان واحد
- ✅ **تتبع الأداء** - إحصائيات شاملة في الوقت الفعلي
- ✅ **سهولة الاستخدام** - واجهة بديهية بدعم كامل للعربية
- ✅ **مراقبة النظام** - صحة النظام والأدوات
- ✅ **إدارة المشاريع** - تتبع المشاريع والأنشطة

---

## 🌟 المميزات الرئيسية

### 1. **إحصائيات شاملة**

```typescript
interface DashboardStats {
  total_projects: number;        // إجمالي المشاريع
  active_tools: number;          // الأدوات النشطة
  completed_calculations: number; // الحسابات المنجزة
  system_health: number;         // صحة النظام (%)
  last_update: string;           // آخر تحديث
}
```

### 2. **تصنيف الأدوات**

الأدوات مصنفة في **8 فئات رئيسية**:

| الفئة | العدد | الوصف |
|------|------|-------|
| 🔧 الأدوات الأساسية | 4 | محول، مقدر، حديد، تقدير |
| 💰 التقدير والتكاليف | 5 | BOQ، تحليل، تمويل، أحمال |
| 📐 أدوات التصميم | 6 | RCC، قطع، جداول، خرسانة |
| 📊 أدوات التحليل | 5 | إنشائي، تربة، أساسات، مواد |
| 🚗 النقل والمسح | 2 | طرق، مسح |
| 📚 التعليم والمراجع | 2 | فيديو، دليل مباني |
| ⭐ أدوات خاصة | 4 | CV، تربة، أساس، استيفاء |
| 📁 إدارة المشاريع | 2 | تتبع، مهام |

### 3. **البحث والتصفية**

- 🔍 **بحث نصي** - ابحث عن أي أداة بالاسم
- 🏷️ **تصفية حسب الفئة** - عرض أدوات فئة معينة
- 📊 **ترتيب حسب الاستخدام** - الأدوات الأكثر استخداماً أولاً

### 4. **النشاطات الأخيرة**

تتبع جميع الأنشطة في الوقت الفعلي:

```typescript
interface RecentActivity {
  id: string;
  tool: string;           // اسم الأداة
  action: string;         // الإجراء المنفذ
  timestamp: string;      // وقت التنفيذ
  user: string;           // المستخدم
  status: 'success' | 'warning' | 'error';
}
```

### 5. **صحة النظام**

مراقبة شاملة لصحة النظام:

- 🗄️ **صحة قاعدة البيانات** - اتصال وأداء
- 🌐 **صحة API** - معدل الأخطاء والاستجابة
- 🔧 **صحة الأدوات** - الأدوات المستخدمة والنشطة
- ⚠️ **المشاكل** - قائمة بالمشاكل الحالية

---

## 🛠️ الأدوات المتكاملة

### 1. الأدوات الأساسية (Basic Tools)

#### 1.1 محول الوحدات (Unit Converter)

**الوصف:** تحويل بين الوحدات المختلفة

**الوحدات المدعومة:**
- 📏 الطول: متر، قدم، سنتيمتر، بوصة
- 📐 المساحة: متر²، قدم²، هكتار، فدان
- 📦 الحجم: متر³، قدم³، لتر، جالون
- ⚖️ الوزن: كيلوجرام، طن، باوند، جرام
- 💨 الضغط: باسكال، بار، PSI
- ⚡ القوة: نيوتن، كيلونيوتن
- 🌡️ الحرارة: مئوية، فهرنهايت، كلفن

**مثال استخدام:**

```typescript
// تحويل 100 متر إلى قدم
POST /api/unit-convert
{
  "value": 100,
  "from_unit": "meter",
  "to_unit": "feet",
  "unit_type": "length"
}

// النتيجة
{
  "success": true,
  "original": { "value": 100, "unit": "meter" },
  "converted": { "value": 328.084, "unit": "feet" }
}
```

#### 1.2 مقدر المباني (Building Estimator)

**الوصف:** تقدير سريع لتكاليف البناء

**المعاملات:**
- 🏗️ نوع المبنى: سكني، تجاري، صناعي، إداري، فيلا، مستودع، مدرسة
- 🌍 المنطقة: 8 مناطق (السعودية، الإمارات، مصر، قطر، الكويت، عمان، البحرين، الأردن)
- ✨ مستوى التشطيب: عادي، جيد، ممتاز، فاخر
- 📏 المساحة: بالمتر المربع

**مثال:**

```typescript
POST /api/quick-estimate
{
  "building_area": 500,
  "building_type": "residential",
  "finish_level": "good",
  "region": "saudi_arabia",
  "num_floors": 2
}

// النتيجة
{
  "success": true,
  "estimate": {
    "total_cost": 1250000,
    "currency": "SAR",
    "cost_per_sqm": 2500,
    "materials": { ... },
    "confidence": "medium"
  }
}
```

#### 1.3 حاسبة وزن الحديد (Steel Weight Calculator)

**الوصف:** حساب دقيق لوزن الحديد

**الصيغة:** `الوزن = (القطر² / 162) × الطول`

**الأقطار المدعومة:** 6mm، 8mm، 10mm، 12mm، 14mm، 16mm، 18mm، 20mm، 22mm، 25mm، 28mm، 32mm

**مثال:**

```python
# حساب وزن 100 متر من حديد قطر 16mm
from core.civil_concept_tools import DesignToolsService

weight = DesignToolsService.calculate_steel_weight(16, 100)
print(f"الوزن: {weight} كجم")  # النتيجة: 158.02 كجم
```

---

### 2. أدوات التقدير والتكاليف (Estimation & Costing)

#### 2.1 تحليل الأسعار (Rate Analysis)

**الوصف:** تحليل تفصيلي لأسعار المواد والعمالة

**المكونات:**
- 📦 المواد: أسعار وكميات
- 👷 العمالة: أجور وإنتاجية
- 🚜 المعدات: تكاليف تشغيل
- 💼 التكاليف الإضافية: إدارة، نقل

#### 2.2 مولد BOQ (BOQ Maker)

**الوصف:** إنشاء جداول الكميات والأسعار

**المميزات:**
- ✅ إنشاء تلقائي
- 📊 حساب التكاليف
- 📄 تصدير Excel
- 📈 تقارير احترافية

**مثال:**

```typescript
interface BOQItem {
  itemNo: number;
  description: string;
  unit: string;
  quantity: number;
  rate: number;
  amount: number;
}
```

#### 2.3 حاسبة الأحمال (Load Calculator)

**الوصف:** حساب الأحمال على العناصر الإنشائية

**أنواع الأحمال:**

1. **الأحمال الميتة (Dead Load):**
   - وزن العناصر الإنشائية
   - المواد الدائمة
   - التشطيبات

2. **الأحمال الحية (Live Load):**
   - الاستخدام
   - الأثاث والمعدات
   - الأشخاص

3. **أحمال الرياح (Wind Load):**
   - سرعة الرياح
   - ارتفاع المبنى
   - المساحة المعرضة

4. **أحمال الزلازل (Seismic Load):**
   - الوزن الكلي
   - معامل الزلازل
   - منطقة الزلزال

**مثال:**

```python
from core.civil_concept_tools import EstimationToolsService

loads = EstimationToolsService.calculate_loads({
    'area': 100,  # متر مربع
    'dead_load_factor': 5,  # kN/m²
    'live_load_factor': 2,  # kN/m²
    'wind_speed': 40,  # m/s
    'building_height': 20,  # متر
    'seismic_zone': 2,
    'building_weight': 5000  # kN
})

print(f"الحمل الميت: {loads['dead_load']} kN")
print(f"الحمل الحي: {loads['live_load']} kN")
print(f"حمل الرياح: {loads['wind_load']} kN")
print(f"حمل الزلزال: {loads['seismic_load']} kN")
print(f"الحمل الكلي: {loads['total_load']} kN")
```

---

### 3. أدوات التصميم (Design Tools)

#### 3.1 تصميم الخرسانة المسلحة (RCC Design)

**الوصف:** تصميم عناصر الخرسانة المسلحة

**العناصر المدعومة:**
- 🏛️ الأعمدة (Columns)
- 🌉 الكمرات (Beams)
- 🏗️ الأساسات (Foundations)
- 🏢 الأرضيات (Slabs)

**مثال - تصميم عمود:**

```python
from core.civil_concept_tools import DesignToolsService

column_design = DesignToolsService.design_rcc(
    element_type='column',
    load=1000,  # kN
    dimensions={'width': 0.4, 'depth': 0.4},  # متر
    concrete_grade='M30',
    steel_grade='Fe500'
)

print(f"مساحة الحديد المطلوبة: {column_design['required_steel_area']} mm²")
print(f"عدد الأسياخ: {column_design['number_of_bars']}")
print(f"قطر السيخ: {column_design['bar_diameter']} mm")
```

#### 3.2 طول القطع (Cutting Length)

**الوصف:** حساب طول قطع الحديد

**الصيغة:** `طول القطع = الطول الأساسي + 2×الغطاء + 2×الانحناء`

**مثال:**

```python
from core.civil_concept_tools import DesignToolsService

cutting_length = DesignToolsService.calculate_cutting_length(
    span_length=5.0,  # متر
    cover=0.05,  # متر
    diameter=16,  # mm
    bend_type='standard'
)

print(f"طول القطع: {cutting_length['cutting_length']} م")
print(f"الطول الأساسي: {cutting_length['main_length']} م")
print(f"طول الانحناء: {cutting_length['bend_length']} م")
```

#### 3.3 جدول تسليح الحديد (Bar Bending Schedule)

**الوصف:** إنشاء جدول تسليح الحديد (BBS)

**المحتوى:**
- رقم السيخ
- القطر
- العدد
- طول القطع
- الوزن الكلي
- الرسم التوضيحي

---

### 4. أدوات التحليل (Analysis Tools)

#### 4.1 التحليل الإنشائي (Structural Analysis)

**الوصف:** تحليل الهياكل والإجهادات

**أنواع التحليل:**
- 📊 تحليل الإجهادات (Stress Analysis)
- 📉 تحليل الانحرافات (Deflection Analysis)
- 🔄 تحليل الاستقرار (Stability Analysis)
- 🌊 تحليل ديناميكي (Dynamic Analysis)

#### 4.2 ميكانيكا التربة (Soil Mechanics)

**الوصف:** حسابات وتحليلات التربة

**الحسابات:**

1. **الإجهاد الفعال:**
   ```
   σ' = σ - u
   ```
   حيث:
   - σ' = الإجهاد الفعال
   - σ = الإجهاد الكلي
   - u = ضغط الماء المسامي

2. **مقاومة القص:**
   ```
   τ = c + σ' × tan(φ)
   ```
   حيث:
   - τ = مقاومة القص
   - c = التماسك
   - φ = زاوية الاحتكاك الداخلي

3. **القدرة الحاملة:**
   ```
   q_ult = c×N_c + γ×D_f×N_q + 0.5×γ×B×N_γ
   ```

**مثال:**

```python
from core.civil_concept_tools import AnalysisToolsService

soil_analysis = AnalysisToolsService.analyze_soil({
    'soil_type': 'clay',
    'unit_weight': 18,  # kN/m³
    'cohesion': 25,  # kPa
    'friction_angle': 28,  # درجة
    'depth': 2.0,  # متر
    'water_table_depth': 1.5  # متر
})

print(f"الإجهاد الفعال: {soil_analysis['effective_stress']} kPa")
print(f"مقاومة القص: {soil_analysis['shear_strength']} kPa")
print(f"القدرة الحاملة: {soil_analysis['bearing_capacity']} kPa")
```

#### 4.3 هندسة الأساسات (Foundation Engineering)

**الوصف:** تصميم وتحليل الأساسات

**أنواع الأساسات:**

1. **أساسات سطحية:**
   - أساسات منفصلة (Isolated Footings)
   - أساسات مشتركة (Combined Footings)
   - أساسات شريطية (Strip Footings)
   - أساسات حصيرة (Mat Foundations)

2. **أساسات عميقة:**
   - خوازيق (Piles)
   - كيسونات (Caissons)

**مثال:**

```python
from core.civil_concept_tools import AnalysisToolsService

foundation_design = AnalysisToolsService.design_foundation({
    'column_load': 1000,  # kN
    'soil_bearing_capacity': 200,  # kPa
    'foundation_type': 'isolated',
    'depth': 1.5,  # متر
    'safety_factor': 3
})

print(f"مساحة الأساس المطلوبة: {foundation_design['required_area']} m²")
print(f"الأبعاد المقترحة: {foundation_design['dimensions']}")
print(f"نوع الأساس: {foundation_design['foundation_type']}")
```

---

## 💻 واجهة المستخدم

### 1. الشاشة الرئيسية

```
┌─────────────────────────────────────────────────────┐
│  🏗️ نظام نوفل الهندسي                              │
│  لوحة التحكم الموحدة - 30+ أداة متكاملة            │
│                                                     │
│  [العربية / English]  🔔  👤                        │
└─────────────────────────────────────────────────────┘

┌──────────┬──────────┬──────────┬──────────┐
│ 📁 42    │ 🔧 30    │ ⚡ 1567  │ 💚 98.5% │
│ المشاريع │ الأدوات  │ الحسابات │ الصحة    │
└──────────┴──────────┴──────────┴──────────┘

┌─────────────────────────────────────────┐
│  🔍 ابحث عن أداة...                    │
│  [الكل] [أساسي] [تقدير] [تصميم] ...   │
└─────────────────────────────────────────┘
```

### 2. بطاقة الأداة

```
┌────────────────────────────────────────┐
│  📐 محول الوحدات                      │
│  تحويل بين الوحدات المختلفة           │
│                                        │
│  [نشط] [بسيط]        🔄 1,234         │
└────────────────────────────────────────┘
```

### 3. الأنشطة الأخيرة

```
┌────────────────────────────────────────┐
│  🕐 النشاطات الأخيرة                  │
│                                        │
│  ✅ BOQ Maker                          │
│     Created new BOQ for Project X     │
│     Ahmed • منذ 5 دقائق               │
│                                        │
│  ✅ RCC Design                         │
│     Designed column C1                │
│     Mohammed • منذ 10 دقائق           │
└────────────────────────────────────────┘
```

---

## 📡 API Documentation

### Base URL

```
http://localhost:5000/api
```

### Authentication

حالياً لا توجد مصادقة مطلوبة. سيتم إضافتها في الإصدارات القادمة.

### Endpoints

#### 1. Dashboard Stats

```http
GET /dashboard/stats
```

**Response:**
```json
{
  "success": true,
  "stats": {
    "total_projects": 42,
    "active_tools": 30,
    "completed_calculations": 1567,
    "system_health": 98.5,
    "last_update": "2025-11-04T12:00:00Z"
  }
}
```

#### 2. Tool Usage

```http
GET /dashboard/tool-usage?limit=30
```

**Response:**
```json
{
  "success": true,
  "tools": [
    {
      "tool_id": "converter",
      "tool_name": "Unit Converter",
      "tool_name_ar": "محول الوحدات",
      "category": "basic",
      "usage_count": 1234,
      "last_used": "2025-11-04T11:45:00Z",
      "avg_execution_time": 0.15
    }
  ]
}
```

#### 3. Recent Activities

```http
GET /dashboard/recent-activities?limit=20
```

**Response:**
```json
{
  "success": true,
  "activities": [
    {
      "id": "1",
      "tool_id": "boq_maker",
      "tool_name": "BOQ Maker",
      "action": "Created new BOQ",
      "action_ar": "إنشاء BOQ جديد",
      "timestamp": "2025-11-04T11:55:00Z",
      "user": "Ahmed",
      "status": "success",
      "execution_time": 2.5
    }
  ]
}
```

#### 4. System Health

```http
GET /dashboard/system-health
```

**Response:**
```json
{
  "success": true,
  "health": {
    "overall_health": 98.5,
    "database_health": 100.0,
    "api_health": 99.0,
    "tools_health": 96.5,
    "last_check": "2025-11-04T12:00:00Z",
    "issues": []
  }
}
```

#### 5. Log Usage

```http
POST /dashboard/log-usage
Content-Type: application/json

{
  "tool_id": "converter",
  "tool_name": "Unit Converter",
  "tool_name_ar": "محول الوحدات",
  "category": "basic",
  "user": "Ahmed",
  "execution_time": 0.15,
  "status": "success",
  "details": {
    "from_unit": "meter",
    "to_unit": "feet",
    "value": 100
  }
}
```

---

## 🎓 أمثلة الاستخدام

### مثال 1: تقدير سريع لمبنى

```python
import requests

# تقدير تكلفة فيلا 500 متر
response = requests.post('http://localhost:5000/api/quick-estimate', json={
    'building_area': 500,
    'building_type': 'villa',
    'finish_level': 'excellent',
    'region': 'saudi_arabia',
    'num_floors': 2
})

result = response.json()
if result['success']:
    estimate = result['estimate']
    print(f"التكلفة الإجمالية: {estimate['total_cost']:,} {estimate['currency']}")
    print(f"التكلفة للمتر المربع: {estimate['cost_per_sqm']:,} {estimate['currency']}")
    print(f"مستوى الثقة: {estimate['confidence']}")
```

### مثال 2: حساب وزن الحديد

```python
from core.civil_concept_tools import DesignToolsService

# حساب وزن حديد 16mm بطول 100 متر
weight = DesignToolsService.calculate_steel_weight(
    diameter=16,
    length=100
)

print(f"وزن الحديد: {weight:.2f} كجم")
# النتيجة: وزن الحديد: 158.02 كجم
```

### مثال 3: تحليل مخطط منزل

```python
import requests

# تحليل مخطط من CivilConcept
response = requests.post('http://localhost:5000/api/house-plan/analyze', json={
    'url': 'https://civilconcept.com/house-plan/123'
})

result = response.json()
if result['success']:
    plan = result['plan']
    stats = result['statistics']
    
    print(f"اسم المخطط: {plan['title']}")
    print(f"مساحة الأرض: {stats['land_area']} متر مربع")
    print(f"مساحة البناء: {stats['building_area']} متر مربع")
    print(f"عدد الغرف: {stats['total_rooms']}")
```

### مثال 4: مقارنة مخططين

```python
import requests

# مقارنة مخططين
response = requests.post('http://localhost:5000/api/house-plan/compare', json={
    'url1': 'https://civilconcept.com/house-plan/123',
    'url2': 'https://civilconcept.com/house-plan/456',
    'region': 'saudi_arabia'
})

result = response.json()
if result['success']:
    comparison = result['comparison']
    
    print("مقارنة المخططات:")
    print(f"المخطط 1: {comparison['estimates']['plan1']['plan_title']}")
    print(f"التكلفة: {comparison['estimates']['plan1']['quick_estimate']['total_cost']}")
    
    print(f"\nالمخطط 2: {comparison['estimates']['plan2']['plan_title']}")
    print(f"التكلفة: {comparison['estimates']['plan2']['quick_estimate']['total_cost']}")
```

---

## 🔐 الأمان والصلاحيات

### المستويات الحالية

- ✅ **الوصول المفتوح** - جميع الأدوات متاحة حالياً
- 🔜 **المصادقة** - قريباً
- 🔜 **الصلاحيات** - قريباً
- 🔜 **سجل التدقيق** - قريباً

### الإصدارات القادمة

```typescript
interface User {
  id: string;
  username: string;
  role: 'admin' | 'engineer' | 'viewer';
  permissions: string[];
}

interface Permission {
  tool_id: string;
  can_view: boolean;
  can_use: boolean;
  can_export: boolean;
}
```

---

## 📊 الإحصائيات والتقارير

### أنواع التقارير

1. **تقرير يومي**
   - استخدام الأدوات
   - الحسابات المنجزة
   - أخطاء النظام

2. **تقرير أسبوعي**
   - اتجاهات الاستخدام
   - الأدوات الأكثر شعبية
   - أداء النظام

3. **تقرير شهري**
   - ملخص المشاريع
   - إحصائيات المستخدمين
   - تحليل الأداء

---

## 🚀 التحديثات القادمة

### الإصدار 1.1 (قريباً)

- ✅ نظام المصادقة والصلاحيات
- ✅ تصدير التقارير (PDF/Excel)
- ✅ إشعارات الوقت الفعلي
- ✅ لوحات تحكم مخصصة
- ✅ تكامل مع الأنظمة الخارجية

### الإصدار 1.2 (المستقبل)

- ✅ ذكاء اصطناعي للتوصيات
- ✅ تحليلات متقدمة
- ✅ تطبيق موبايل
- ✅ API عامة

---

## 📞 الدعم والمساعدة

### التواصل

- 📧 Email: support@noufal-ems.com
- 💬 Chat: داخل التطبيق
- 📚 Documentation: docs.noufal-ems.com

### الموارد

- [دليل المستخدم الكامل](./user_guide_ar.md)
- [API Reference](./api_reference.md)
- [أمثلة البرمجة](../examples/)
- [الأسئلة الشائعة](./faq_ar.md)

---

## 📝 الملاحظات النهائية

### النصائح

1. ✅ استخدم البحث للعثور على الأدوات بسرعة
2. ✅ راقب صحة النظام بانتظام
3. ✅ استخدم التقارير لتحليل الأداء
4. ✅ حافظ على تحديث النظام

### التحذيرات

- ⚠️ احفظ عملك بانتظام
- ⚠️ تأكد من دقة المدخلات
- ⚠️ راجع النتائج قبل استخدامها
- ⚠️ استخدم نسخ احتياطية للبيانات المهمة

---

**© 2025 نظام نوفل الهندسي - NOUFAL Engineering Management System**  
**الإصدار 1.0 - جميع الحقوق محفوظة**
